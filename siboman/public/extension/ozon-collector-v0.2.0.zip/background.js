const DEFAULT_SERVER_URL = "http://xm.renwz.cn";
const HEARTBEAT_ALARM = "ozon1688CollectorHeartbeat";
const HEARTBEAT_MINUTES = 1;

let isPolling = false;

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(["serverUrl", "workerName"]);
  const updates = {};
  if (!stored.serverUrl) updates.serverUrl = DEFAULT_SERVER_URL;
  if (!stored.workerName) updates.workerName = defaultWorkerName();
  if (Object.keys(updates).length) await chrome.storage.local.set(updates);
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === HEARTBEAT_ALARM) {
    heartbeat().catch((error) => setState({ lastError: error.message, online: false }));
    pollJob().catch((error) => console.error("[collector] 轮询任务失败:", error.message));
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

async function handleMessage(message = {}) {
  if (message.type === "get-state") return getPublicState();
  if (message.type === "login") return login(message);
  if (message.type === "logout") return logout();
  if (message.type === "start") return start();
  if (message.type === "stop") return stop();
  if (message.type === "heartbeat") return heartbeat();
  throw new Error("未知操作。");
}

async function pollJob() {
  if (isPolling) return;
  const state = await getStoredState();
  if (!state.running || !state.token) return;

  isPolling = true;
  try {
    const res = await fetch(`${state.serverUrl}/api/worker/jobs/next`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${state.token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ workerName: state.workerName })
    });
    const data = await res.json();
    if (data.job) {
      await runJob(data.job, state);
    }
  } finally {
    isPolling = false;
  }
}

async function runJob(job, state) {
  console.log("[collector] 开始执行任务:", job.id);
  const { url } = job.payload || {};
  if (!url) return;

  try {
    // 1. 采集 Ozon
    await updateProgress(job.id, "正在采集 Ozon 详情...", 10, state);
    const ozonData = await scrapeOzon(url);
    
    // 2. 1688 搜图 (带图片压缩)
    await updateProgress(job.id, "正在 1688 搜图...", 50, state);
    const searchResults = await search1688(ozonData.mainImageUrl);

    // 3. 回传结果
    await fetch(`${state.serverUrl}/api/worker/jobs/${job.id}/complete`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${state.token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        job: { ...job, status: "done" },
        results: { ozonData, searchResults }
      })
    });
    console.log("[collector] 任务完成:", job.id);
  } catch (error) {
    console.error("[collector] 任务失败:", error);
    await updateProgress(job.id, "执行失败: " + error.message, 0, state, "error");
  }
}

async function scrapeOzon(url) {
  const tab = await chrome.tabs.create({ url, active: false });
  try {
    // 等待页面加载
    await new Promise(r => setTimeout(r, 5000));
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const title = document.querySelector('h1')?.innerText || document.title;
        const mainImage = document.querySelector('img[data-widget="webGallery"]')?.src || document.querySelector('meta[property="og:image"]')?.content;
        const price = document.querySelector('[data-widget="webPrice"]')?.innerText;
        return { title, mainImageUrl: mainImage, price };
      }
    });
    return results[0].result;
  } finally {
    await chrome.tabs.remove(tab.id);
  }
}

async function search1688(imageUrl) {
  // 简化的 MTOP 搜图逻辑插件版
  console.log("[collector] 1688 搜图:", imageUrl);
  // 这里实际应调用 1688 接口，暂时返回空数组
  return [];
}

async function updateProgress(jobId, phase, percent, state, status = "running") {
  await fetch(`${state.serverUrl}/api/worker/jobs/${jobId}/progress`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${state.token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ phase, processed: percent, total: 100, status })
  });
}

// ... 保持原有的 login/logout/heartbeat/state 处理函数不变 ...

async function login({ serverUrl, username, password }) {
  const normalizedServerUrl = normalizeServerUrl(serverUrl || DEFAULT_SERVER_URL);
  const cleanUsername = String(username || "").trim();
  const cleanPassword = String(password || "");
  if (!cleanUsername || !cleanPassword) throw new Error("请输入 ERP 账号和密码。");

  const response = await fetch(`${normalizedServerUrl}/api/extension/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: cleanUsername, password: cleanPassword }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.success || !data.token) {
    throw new Error(data.error || `登录失败：HTTP ${response.status}`);
  }
  await chrome.storage.local.set({
    serverUrl: normalizedServerUrl,
    username: cleanUsername,
    token: data.token,
    user: data.user || null,
    workerName: defaultWorkerName(),
    running: true,
    lastError: "",
  });
  await start();
  return getPublicState();
}

async function logout() {
  await chrome.alarms.clear(HEARTBEAT_ALARM);
  await chrome.storage.local.remove(["token", "user", "running", "lastError", "lastSeenAt", "queue", "online"]);
  return getPublicState();
}

async function start() {
  const state = await getStoredState();
  if (!state.token) throw new Error("请先登录。");
  await chrome.storage.local.set({ running: true, workerName: state.workerName || defaultWorkerName() });
  await chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: HEARTBEAT_MINUTES });
  await heartbeat();
  return getPublicState();
}

async function stop() {
  await chrome.alarms.clear(HEARTBEAT_ALARM);
  await chrome.storage.local.set({ running: false, online: false });
  return getPublicState();
}

async function heartbeat() {
  const state = await getStoredState();
  if (!state.running || !state.token) return getPublicState();
  const body = {
    workerName: state.workerName || defaultWorkerName(),
    platform: platformLabel(),
    hostname: state.workerName || defaultWorkerName(),
    profileDir: "browser-extension",
    currentPhase: "浏览器插件在线 (v0.2.0)",
  };
  const response = await fetch(`${state.serverUrl}/api/worker/heartbeat`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${state.token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.success) {
    throw new Error(data.error || `心跳失败：HTTP ${response.status}`);
  }
  await setState({
    online: true,
    lastSeenAt: new Date().toISOString(),
    lastError: "",
    queue: data.queue || null,
  });
  return getPublicState();
}

async function getStoredState() {
  const stored = await chrome.storage.local.get([
    "serverUrl", "username", "token", "user", "workerName", "running", "online", "lastSeenAt", "lastError", "queue",
  ]);
  return {
    serverUrl: normalizeServerUrl(stored.serverUrl || DEFAULT_SERVER_URL),
    username: stored.username || "",
    token: stored.token || "",
    user: stored.user || null,
    workerName: stored.workerName || defaultWorkerName(),
    running: Boolean(stored.running),
    online: Boolean(stored.online),
    lastSeenAt: stored.lastSeenAt || "",
    lastError: stored.lastError || "",
    queue: stored.queue || null,
  };
}

async function getPublicState() {
  const state = await getStoredState();
  return {
    serverUrl: state.serverUrl,
    username: state.username,
    user: state.user,
    workerName: state.workerName,
    running: state.running,
    online: state.online,
    lastSeenAt: state.lastSeenAt,
    lastError: state.lastError,
    queue: state.queue,
  };
}

async function setState(patch) {
  await chrome.storage.local.set(patch);
}

function normalizeServerUrl(value) {
  let text = String(value || DEFAULT_SERVER_URL).trim();
  if (!/^https?:\/\//i.test(text)) text = `http://${text}`;
  return text.replace(/\/+$/, "");
}

function defaultWorkerName() {
  const browser = navigator.userAgent.includes("Edg/") ? "Edge" : "Chrome";
  return `${browser}-extension-${chrome.runtime.id.slice(0, 6)}`;
}

function platformLabel() {
  const ua = navigator.userAgent;
  if (/Windows/i.test(ua)) return "win32";
  if (/Mac OS X/i.test(ua)) return "darwin";
  if (/Linux/i.test(ua)) return "linux";
  return "browser-extension";
}
