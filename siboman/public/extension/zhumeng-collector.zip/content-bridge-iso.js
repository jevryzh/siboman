/**
 * 逐梦 Ozon 采集器 - Content Bridge (ISOLATED world) v1.0.6
 *
 * v1.0.6 改动 (修复跨 world postMessage 不可靠):
 *   - 不再用 postMessage reply, 改用 document CustomEvent
 *   - document 在 ISOLATED 跟 MAIN world 共享, CustomEvent 100% 跨 world 投递
 *   - 配合 content-bridge-main.js (MAIN world) 使用
 */
(function () {
  "use strict";
  const PROTO = "__zhumeng_proto";
  const PROTO_VAL = "zhumeng-v1";
  const VERSION = "1.0.6";

  console.log(`[逐梦采集器 v${VERSION}][ISO] 启动`);

  function replyToMain(reqId, kind, payload) {
    const replyMsg = { [PROTO]: PROTO_VAL, reqId, kind, ...payload };
    document.dispatchEvent(new CustomEvent("__zhumeng_reply__", { detail: replyMsg }));
  }

  function broadcastReadyToMain(version) {
    document.dispatchEvent(new CustomEvent("__zhumeng_reply__", {
      detail: { [PROTO]: PROTO_VAL, kind: "ready", version }
    }));
  }

  // 监听 main world dispatch 的 __zhumeng_request__ CustomEvent
  document.addEventListener("__zhumeng_request__", async (event) => {
    const data = event.detail;
    if (!data || data[PROTO] !== PROTO_VAL) return;

    const { reqId, kind } = data;
    console.log(`[逐梦采集器 v${VERSION}][ISO] 收到 kind=${kind} reqId=${reqId}`);

    if (kind === "ping.request") {
      console.log(`[逐梦采集器 v${VERSION}][ISO] → reply ping.response`);
      replyToMain(reqId, "ping.response", { ok: true, version: VERSION });
      return;
    }

    if (kind === "status.request") {
      try {
        const resp = await chrome.runtime.sendMessage({ action: "checkStatus" });
        replyToMain(reqId, "status.response", resp);
      } catch (e) {
        replyToMain(reqId, "status.response", { ok: false, error: e.message });
      }
      return;
    }

    if (kind === "diagnose.request") {
      try {
        const resp = await chrome.runtime.sendMessage({ action: "diagnose" });
        replyToMain(reqId, "diagnose.response", resp);
      } catch (e) {
        replyToMain(reqId, "diagnose.response", { ok: false, error: e.message });
      }
      return;
    }

    if (kind === "collect.request") {
      const skus = data.skus || [];
      const storeIds = data.storeIds || [];
      console.log(`[逐梦采集器 v${VERSION}][ISO] collect.request: ${skus.length} SKU, ${storeIds.length} stores`);
      if (!skus.length) {
        replyToMain(reqId, "collect.response", { ok: false, error: "skus 为空" });
        return;
      }
      try {
        const resp = await chrome.runtime.sendMessage({ action: "collectSkus", skus, storeIds });
        console.log(`[逐梦采集器 v${VERSION}][ISO] collect 完成 ok=${resp?.ok} 成功=${Object.keys(resp?.results||{}).length}`);
        replyToMain(reqId, "collect.response", resp);
      } catch (e) {
        console.error(`[逐梦采集器 v${VERSION}][ISO] collect 异常:`, e.message);
        replyToMain(reqId, "collect.response", { ok: false, error: e.message });
      }
      return;
    }
  });

  // 持续 broadcast ready (每 1s × 10 次, 通过 CustomEvent 投递到 main world)
  let readyCount = 0;
  const broadcastReady = () => {
    if (readyCount >= 10) return;
    broadcastReadyToMain(VERSION);
    console.log(`[逐梦采集器 v${VERSION}][ISO] broadcast ready #${readyCount + 1}`);
    readyCount++;
    setTimeout(broadcastReady, 1000);
  };
  broadcastReady();
})();
