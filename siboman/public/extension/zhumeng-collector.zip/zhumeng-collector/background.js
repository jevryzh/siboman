/**
 * 逐梦 Ozon 采集器 - Service Worker v1.0.7
 *
 * v1.0.7 重大改动 (采集策略重写):
 *   - 不再调 seller.ozon.ru 后台 API (会 403 PermissionDenied)
 *   - 改用: 打开 https://www.ozon.ru/product/<sku>/ 商品前端页, 用 executeScript 注入函数提取 DOM 数据
 *   - Ozon 商品前端页是公开的, 不需要登录
 *   - 关闭 tab 用完后立即关
 *
 * v1.0.4-1.0.6 改动保留:
 *   - 详细 console.log
 *   - diagnose action
 */

const VERSION = "2.2.9.36";
const OZON_FRONTEND_ORIGIN = "https://www.ozon.ru";
const OZON_PRODUCT_URL = (sku) => `https://www.ozon.ru/product/${sku}/`;
const OPI_BASE_URL = "https://api-seller.ozon.ru";
const ERP_BACKEND_ORIGIN = "https://test.renwz.cn";  // ERP 后端 (拿凭证)
const MTOP_URL = "https://h5api.m.1688.com/h5/mtop.relationrecommend.wirelessrecommend.recommend/2.0/";
const MTOP_APP_KEY = "12574478";
const WORKER_NAME = `zhumeng-plugin-${chrome.runtime.id.slice(0, 8)}`;
let sourcingBusy = false;
let workerAuthToken = "";

// ========== 采集核心: 打开 Ozon 商品前端页 + executeScript 提取 ==========
async function collectSku(sku, storeIds = []) {
  const url = OZON_PRODUCT_URL(sku);
  console.log(`[SW ${VERSION}] 采集 SKU ${sku}: 准备打开 ${url}, stores=${storeIds.length}`);
  
  // 1. 打开 Ozon 商品页 (后台 tab, 不打扰用户)
  const tab = await chrome.tabs.create({ url, active: false });
  console.log(`[SW ${VERSION}] 已创建 tab id=${tab.id}, 等待页面加载...`);
  
  // 2. 等待页面加载完成 (最多 30s)
  try {
    await waitForTabComplete(tab.id, 30000);
  } catch (e) {
    await safeRemoveTab(tab.id);
    throw new Error(`Ozon 商品页加载超时/失败: ${e.message}`);
  }

// v2.2.9.1: Ozon SPA 异步渲染, status=complete 后 [data-widget="breadCrumbs"] 可能还没出现
  // v2.2.9.7: Chrome 后台 tab JS throttle 严重 (lazy-load 元素可能 5-10s 才出现), polling 5×1s 不够
  //   1) maxRetries 5 → 15, 间隔 1000ms → 2000ms (最多等 30s)
  //   2) exit 条件放宽: result.name 有就 break (不再强求 cat > 0), 后面 category-resolve 用 candidates 自动补
  //   3) executeScript 抛错时打印, 方便 debug
  // v2.2.9.8: 增强 debug — 每次 polling 后打印 result 类型 + tab status + 名字, 30s 全空时报最后 raw
  let result = null;
  let lastRaw = null;
  const maxRetries = 15;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const [execResult] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractOzonProductData,
        args: [sku],
      });
      result = execResult?.result;
      if (result) lastRaw = JSON.stringify(result).slice(0, 300);
    } catch (e) {
      console.warn(`[SW ${VERSION}]   attempt ${attempt} executeScript 抛错: ${e.message}`);
    }
    // v2.2.9.8: extract 函数本身 try/catch 抛错时会在 result._error 字段, 这里打印到 SW console (user 能看)
    if (result && result._error) {
      console.error(`[SW ${VERSION}]   attempt ${attempt} extract 内部抛错: ${result._error} | stack=${result._stack}`);
    }
    // v2.2.9.7: 放宽 exit 条件 — name 拿到就 break (cat 可以后续 category-resolve 用 candidates 补)
    if (result && result.name) {
      if (attempt > 1) console.log(`[SW ${VERSION}]   第 ${attempt} 次 retry 拿到 name="${result.name?.slice(0,40)}" cat=${result.description_category_id || 0} attrs=${result.attributes?.length || 0}`);
      break;
    }
    // v2.2.9.8: 详细 debug — 第 1/5/10 次打印 result 类型 + tab status, 让 user 在 service worker console 能看到
    if (attempt === 1 || attempt === 5 || attempt === 10) {
      const tabInfo = await chrome.tabs.get(tab.id).catch(() => null);
      console.log(`[SW ${VERSION}]   attempt ${attempt} result=${result ? `object(name=${result.name?.slice(0,30)||'(empty)'})` : 'null'} tab.status=${tabInfo?.status} url=${tabInfo?.url?.slice(0,60)}`);
    }
    if (attempt < maxRetries) await new Promise(r => setTimeout(r, 2000));
  }
  if (!result && lastRaw) console.warn(`[SW ${VERSION}]   polling 15 次都失败, 最后 raw: ${lastRaw}`);

  if (!result) {
    await safeRemoveTab(tab.id);
    throw new Error("executeScript 返回空 (可能商品页是空或被 Ozon 屏蔽)");
  }
  if (!result.name) {
    await safeRemoveTab(tab.id);
    throw new Error(`未提取到商品名. raw=${JSON.stringify(result).slice(0, 300)}`);
  }

  // v2.2.9.15: 优先复用 Seller 后台“复制商品”链路拿完整跟卖源包。
  // 公开页/OPI 只能兜底，My ERP 的完整属性、尺寸、富内容主要来自这个 bundle item。
  result._plugin_version = VERSION;
  try {
    const bundle = await enrichFromSellerPortalBundle(result, sku, tab.id);
    result._seller_bundle_enriched = Boolean(bundle);
    if (bundle) {
      console.log(`[SW ${VERSION}]   Seller bundle: attrs=${bundle.attrCount} images=${bundle.imageCount} dims=${result.depth}x${result.width}x${result.height} weight=${result.weight}`);
    } else {
      console.log(`[SW ${VERSION}]   Seller bundle: 未找到可复制源包, 继续用公开页/OPI 兜底`);
    }
  } catch (e) {
    result._seller_bundle_enriched = false;
    result._seller_bundle_error = e.message || String(e);
    console.warn(`[SW ${VERSION}]   Seller bundle 增强失败 (非致命): ${result._seller_bundle_error}`);
  }

  // 4. 关闭 tab
  await safeRemoveTab(tab.id);

  // v2.1: 辅源 - Ozon Seller API 找店铺里同款商品复用 attributes
  if (storeIds && storeIds.length > 0 && result.description_category_id && !result._seller_bundle_enriched) {
    try {
      const enriched = await enrichFromOpi(result, storeIds[0]);
      if (enriched) {
        result._opi_enriched = true;
        console.log(`[SW ${VERSION}]   OPI 辅源: 合并 ${enriched.added} 个新 attr, 覆盖 ${enriched.overridden} 个`);
      } else {
        result._opi_enriched = false;
        console.log(`[SW ${VERSION}]   OPI 辅源: 店铺里没找到同款`);
      }
    } catch (e) {
      result._opi_enriched = false;
      result._opi_error = e.message;
      console.warn(`[SW ${VERSION}]   OPI 辅源失败 (非致命): ${e.message}`);
    }
  } else {
    result._opi_enriched = result._seller_bundle_enriched ? "skipped-seller-bundle" : "skipped";
  }

  // v2.3.0: 重新启用 category-resolve, 带 type_id + confidence
//   - 严格名字匹配 (2 token 都中才用, 避免 Лупа/Оплетка 假阳性)
//   - type_id 匹配更稳 (同一 type_id 通常同一类目)
//   - 带回来 candidates 让前端展示供 user 1-click 选
  if (storeIds && storeIds.length > 0 && (result.name || result.type_id)) {
    try {
      const oldCat = result.description_category_id;
      // v2.2.9: 把 5位 breadcrumb 透传给 server, 配合 name+type_id 多信号解析
      const resolved = await resolveSellerCategory(
        result.sku || result.product_id,
        storeIds[0],
        result.type_id,
        Number(result.description_category_id) || 0,  // 5位 breadcrumb
        result.name,  // v2.2.9.3: 让 server candidates 能用 name 关键词匹配
      );
      const hasSellerBundleCategory = !!(result._seller_bundle_source?.description_category_id || result._seller_bundle_source?.type_id);
      if (resolved && resolved.success && !hasSellerBundleCategory) {
        result.description_category_id = resolved.description_category_id;
        if (resolved.type_id && !result.type_id) result.type_id = resolved.type_id;
        result._category_resolved = {
          from: oldCat,
          to: resolved.description_category_id,
          source: resolved.source,
          confidence: resolved.confidence || 'high',
        };
        console.log(`[SW ${VERSION}]   类目解析: ${oldCat} → ${resolved.description_category_id} (${resolved.source}, confidence=${resolved.confidence})`);
      } else if (resolved && !hasSellerBundleCategory) {
        // v2.2.9.1: 不再清零 plugin 已抓到的 cat (5位 breadcrumb)
        // v2.2.9.2: 自动应用 candidates 第一个 (按商品 name 关键词匹配的最高分 cat)
        // v2.2.9.3: 关键修复 — plugin 抓的 5位 breadcrumb 跟 Ozon Seller API 8位 cat 是两套体系
        //   5位 (e.g. 11427) 是公开 URL slug 末尾, 在 Seller API tree 里不存在, 提交会被拒 levels_category_not_found
        //   8位 (e.g. 17029010) 是 Seller API 内部 id, Ozon /v3/product/import 接受
        //   所以: 5位 cat 只用作 candidates 排序参考, 实际提交用 candidates 第一个 8位 cat + 它的 type_id
        //   user 拿到结果后可在 BatchUpload 表格里点"换一个"切换到更准的
        const candidates = resolved.candidates || [];
        let autoCat = 0;  // 默认不提交 cat, 让 server 拒绝触发 user 选
        let autoType = result.type_id;
        let autoSource = 'none';
        let autoConfidence = 'none';
        let autoWarning = '无法获取类目, 请手动从候选选';
        if (candidates.length > 0) {
          // 优先选 ozon-tree-name-match 来源 + 有 cat_id + 有 type_id 的
          //   (没 type_id 的 candidates 来自 type_id 叶子节点, 8位 cat_id 来自父节点, 实际提交时 cat+type 缺一个会被拒)
          const best = candidates.find(c => c.source === 'ozon-tree-name-match' && c.description_category_id && c.type_id > 0)
                    || candidates.find(c => c.description_category_id && c.type_id > 0)
                    || candidates.find(c => c.source === 'ozon-tree-name-match' && c.description_category_id)
                    || candidates.find(c => c.description_category_id);
          if (best) {
            autoCat = best.description_category_id;
            if (best.type_id) autoType = best.type_id;
            autoSource = 'auto-from-candidates';
            autoConfidence = best.match_score >= 2 ? 'high' : 'medium';
            autoWarning = '类目自动从商品名称匹配填上 (不一定最准, 可点"换一个"切换到更合适的)';
            console.log(`[SW ${VERSION}]   自动应用候选: cat=${autoCat} type_id=${autoType || '(无)'} (${best.name}, score=${best.match_score || '-'})`);
          }
        }
        if (autoCat) {
          result.description_category_id = autoCat;
          if (autoType && !result.type_id) result.type_id = autoType;
        } else {
          // 没 candidates, 保留 plugin 抓的 5位 cat (虽然 Ozon 可能拒, 但作为兜底总比 0 强)
          result.description_category_id = oldCat;
          autoSource = 'public-breadcrumb-fallback';
          autoConfidence = 'low';
          autoWarning = '类目来自公开页面 5位 breadcrumb, Seller API tree 找不到, 上架后会被拒, 请去 Ozon 后台改';
          console.log(`[SW ${VERSION}]   无 candidates, 保留 5位 breadcrumb cat=${oldCat} (Ozon 可能拒)`);
        }
        result._category_resolved = {
          from: oldCat,
          to: result.description_category_id,
          source: autoSource,
          confidence: autoConfidence,
          candidates,  // 保留备选, user 可点"换一个"切换
          warning: autoWarning,
        };
        console.log(`[SW ${VERSION}]   类目自动填上: cat=${result.description_category_id} type_id=${autoType || '(待补)'} (${autoSource}, confidence=${autoConfidence})`);
      } else if (resolved && hasSellerBundleCategory) {
        result._category_resolved = {
          from: oldCat,
          to: result.description_category_id,
          source: 'seller-bundle-trusted',
          confidence: 'high',
          candidates: resolved.candidates || [],
          warning: '已使用 Seller bundle 的源类目/类型, 跳过公开页名称候选纠偏',
        };
        console.log(`[SW ${VERSION}]   类目解析: 保留 Seller bundle cat=${result.description_category_id} type=${result.type_id || '(空)'}, 跳过候选覆盖`);
      }
    } catch (e) {
      console.warn(`[SW ${VERSION}]   category-resolve 调用失败 (非致命, 用 URL cat 上传): ${e.message}`);
    }
  }

  // v2.2.9.30: Ozon 公开 composer 偶发不给 richAnnotationJson。
  // 保留真实富文本优先; 抓不到时用源商品图册生成合法 11254，避免 Seller 后台富内容为空。
  ensureSyntheticRichContent(result);

  // v1.0.9: 详细打印每个字段的来源 + 关键数据
  injectRichContentAttr(result);
	  const dbg = result._debug || {};
  console.log(`[SW ${VERSION}] ✓ 采集 ${sku}: ${result.name?.slice(0, 50)}`);
  console.log(`[SW ${VERSION}]   字段: images=${result.images.length} | cat=${result.description_category_id} | type=${result.type_id} | brand=${result.brand || "(空)"} | weight=${result.weight}g | dims=${result.depth}x${result.width}x${result.height} | price=${result.price || "(空)"} | barcode=${result.barcode || "(空)"} | country=${result.country_of_origin || "(空)"}`);
	  console.log(`[SW ${VERSION}]   attributes: ${result.attributes.length} 个, rich=${result.richContent ? result.richContent.length : 0} bytes, opi=${result._opi_enriched}${result._opi_error ? " (error: "+result._opi_error+")" : ""}`);
  if (result.attributes.length > 0) {
    console.log(`[SW ${VERSION}]   attributes 前 3 个: ${JSON.stringify(result.attributes.slice(0, 3))}`);
  }
  console.log(`[SW ${VERSION}]   _debug 详情: ${JSON.stringify(dbg)}`);

	  return result;
	}

function injectRichContentAttr(data) {
  const richContent = typeof data?.richContent === "string" ? data.richContent.trim() : "";
  if (!richContent) return;
  if (!data._sourceVariant || typeof data._sourceVariant !== "object") data._sourceVariant = { attributes: [] };
  const attrs = Array.isArray(data._sourceVariant.attributes) ? data._sourceVariant.attributes : [];
  if (!attrs.some(a => String(a?.key ?? a?.id ?? a?.attribute_id) === "11254")) {
    data._sourceVariant.attributes = [...attrs, { key: "11254", value: richContent }];
  }
  if (!Array.isArray(data.attributes)) data.attributes = [];
  if (!data.attributes.some(a => Number(a?.id ?? a?.attribute_id) === 11254)) {
    data.attributes.push({ id: 11254, name: "JSON Rich Content", value: richContent });
  }
}

function makeLog(message, level = "info") {
  return { at: new Date().toISOString(), level, message };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomInt(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}

async function erpApi(path, { method = "GET", body } = {}) {
  if (!workerAuthToken) {
    const stored = await chrome.storage.local.get(["workerAuthToken"]).catch(() => ({}));
    workerAuthToken = stored.workerAuthToken || "";
  }
  const headers = { Accept: "application/json" };
  if (workerAuthToken) headers.Authorization = `Bearer ${workerAuthToken}`;
  const init = { method, headers, credentials: "include" };
  if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(body);
  }
  const resp = await fetch(`${ERP_BACKEND_ORIGIN}${path}`, init);
  const text = await resp.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
  if (!resp.ok || data.success === false) {
    throw new Error(data.error || `ERP ${resp.status}: ${text.slice(0, 200)}`);
  }
  return data;
}

async function configureWorkerAuth(token) {
  workerAuthToken = String(token || "").trim();
  if (!workerAuthToken) {
    await chrome.storage.local.remove(["workerAuthToken", "workerAuthUpdatedAt"]);
    return { ok: false, error: "插件 token 为空", version: VERSION };
  }
  await chrome.storage.local.set({ workerAuthToken, workerAuthUpdatedAt: Date.now() });
  startSourcingQueueLoop();
  await pollSourcingQueueOnce();
  return { ok: true, version: VERSION, workerName: WORKER_NAME };
}

function workerMeta(currentPhase = "") {
  return {
    workerName: WORKER_NAME,
    platform: "chrome-extension",
    hostname: "Chrome",
    profileDir: chrome.runtime.id,
    currentPhase,
  };
}

async function reportSourcingProgress(job, extra = {}) {
  try {
    const data = await erpApi(`/api/worker/jobs/${encodeURIComponent(job.id)}/progress`, {
      method: "POST",
      body: {
        status: job.status,
        phase: job.phase,
        processed: job.processed,
        total: job.total,
        logs: job.logs,
        results: job.results,
        error: job.error || "",
        ...workerMeta(job.phase),
        ...extra,
      },
    });
    if (data.job?.status === "canceled") job.cancelRequested = true;
    return data;
  } catch (e) {
    console.warn(`[SW ${VERSION}] 单品找货进度回传失败: ${e.message}`);
    return null;
  }
}

async function completeSourcingJob(job) {
  await erpApi(`/api/worker/jobs/${encodeURIComponent(job.id)}/complete`, {
    method: "POST",
    body: {
      job: {
        id: job.id,
        kind: "run",
        status: job.status,
        phase: job.phase,
        total: job.total,
        processed: job.processed,
        logs: job.logs,
        results: job.results,
        error: job.error || "",
      },
      excelBase64: "",
      ...workerMeta(job.phase),
    },
  });
}

function extractOzonSkuFromUrl(url) {
  const text = String(url || "").trim();
  const match = text.match(/(?:product\/[^/?#]*-)?(\d{6,})(?:[/?#]|$)/i) || text.match(/(\d{6,})/);
  return match ? match[1] : "";
}

function normalizeOzonForSourcing(data, url, sourceRow) {
  const images = Array.isArray(data.images) ? data.images.filter(Boolean) : [];
  const mainImageUrl = images[0] || "";
  return {
    sourceUrl: url,
    sku: data.sku || data.product_id || extractOzonSkuFromUrl(url),
    title: data.name || "",
    description: data.description || "",
    attributes: data.attributes || [],
    brand: data.brand || "",
    description_category_id: data.description_category_id || 0,
    type_id: data.type_id || 0,
    currentBlackPriceCny: data.price || "",
    mainImageUrl,
    mainImage: mainImageUrl ? { url: mainImageUrl, publicUrl: mainImageUrl, contentType: "image/jpeg" } : null,
    images,
    raw: data,
    sourceRow,
  };
}

async function runQueuedSourcingJob(remoteJob) {
  const payload = remoteJob.payload || {};
  const options = payload.options || {};
  const rows = Array.isArray(payload.urlRows) && payload.urlRows.length
    ? payload.urlRows
    : (Array.isArray(payload.urls) ? payload.urls.map((url, index) => ({ url, sourceRow: index + 1 })) : []);
  const job = {
    id: remoteJob.id,
    status: "running",
    phase: "插件已领取，准备单品找货",
    total: rows.length,
    processed: Number(remoteJob.processed || 0),
    logs: Array.isArray(remoteJob.logs) ? remoteJob.logs : [],
    results: Array.isArray(remoteJob.results) ? remoteJob.results : [],
    error: "",
    cancelRequested: false,
  };
  job.logs.push(makeLog(`逐梦插件 v${VERSION} 已领取单品找货任务。`));
  await reportSourcingProgress(job);

  const maxCandidates = Math.max(1, Math.min(20, Number(options.maxCandidates || 5)));
  const enable1688 = options.enable1688 !== false;
  const delayMinMs = Math.max(1000, Number(options.delayMinMs || 8000));
  const delayMaxMs = Math.max(delayMinMs, Number(options.delayMaxMs || 20000));

  for (let index = job.processed; index < rows.length; index += 1) {
    if (job.cancelRequested) break;
    const row = rows[index] || {};
    const url = row.url || row;
    const sourceRow = Number(row.sourceRow || index + 1);
    const sku = extractOzonSkuFromUrl(url);
    const result = { url, sourceRow, ozon: null, candidates: [], selectedCandidate: null, aiReview: null };
    try {
      if (!sku) throw new Error("没有识别到 Ozon SKU");
      job.phase = `采集 Ozon 第 ${sourceRow} 行`;
      job.logs.push(makeLog(`开始采集 Ozon SKU ${sku}`));
      await reportSourcingProgress(job);
      const ozonRaw = await collectSku(sku, []);
      result.ozon = normalizeOzonForSourcing(ozonRaw, url, sourceRow);

      if (enable1688 && result.ozon.mainImageUrl) {
        job.phase = `1688 搜图 第 ${sourceRow} 行`;
        job.logs.push(makeLog(`用主图搜索 1688 候选，最多 ${maxCandidates} 个。`));
        await reportSourcingProgress(job);
        const searchResult = await search1688ByImageInPlugin(result.ozon.mainImageUrl, maxCandidates);
        if (searchResult.success) {
          result.candidates = searchResult.candidates;
          result.selectedCandidate = result.candidates[0] || null;
          result.aiReview = {
            decision: result.selectedCandidate ? "needs_review" : "no_match",
            reason: "插件端已完成 1688 搜图和详情采集，AI 严格审核待接入后端评估。",
          };
          job.logs.push(makeLog(`1688 找到 ${result.candidates.length} 个候选。`));
        } else {
          result.searchError = searchResult.error;
          job.logs.push(makeLog(`1688 搜图失败：${searchResult.error}`, "warn"));
        }
      } else if (enable1688) {
        result.searchError = "Ozon 主图为空，无法 1688 搜图";
        job.logs.push(makeLog(result.searchError, "warn"));
      }
    } catch (e) {
      result.error = e.message || String(e);
      job.logs.push(makeLog(`第 ${sourceRow} 行失败：${result.error}`, "error"));
    }
    job.results.push(result);
    job.processed = index + 1;
    job.phase = `已完成 ${job.processed}/${job.total}`;
    await reportSourcingProgress(job);
    if (index < rows.length - 1) await sleep(randomInt(delayMinMs, delayMaxMs));
  }

  job.status = job.cancelRequested ? "canceled" : (job.results.some(r => !r.error) ? "done" : "error");
  job.phase = job.status === "done" ? "已完成，正在生成 Excel" : (job.status === "canceled" ? "已停止" : "全部失败");
  job.error = job.status === "error" ? "单品找货全部失败" : "";
  job.logs.push(makeLog(job.status === "done" ? "单品找货完成。" : job.phase, job.status === "error" ? "error" : "info"));
  await completeSourcingJob(job);
}

async function pollSourcingQueueOnce() {
  if (sourcingBusy) return;
  sourcingBusy = true;
  try {
    const data = await erpApi("/api/worker/jobs/next", {
      method: "POST",
      body: { ...workerMeta("逐梦插件在线，可领取单品找货任务"), kinds: ["run"] },
    });
    if (data.job) {
      console.log(`[SW ${VERSION}] 领取单品找货任务: ${data.job.id}`);
      await runQueuedSourcingJob(data.job);
    }
  } catch (e) {
    const msg = e.message || String(e);
    if (!/请先登录|401/.test(msg)) console.warn(`[SW ${VERSION}] 单品找货轮询失败: ${msg}`);
  } finally {
    sourcingBusy = false;
  }
}

function startSourcingQueueLoop() {
  chrome.alarms.create("zhumeng-single-sourcing", { periodInMinutes: 1 });
  setTimeout(() => pollSourcingQueueOnce(), 1500);
}

async function search1688ByImageInPlugin(imageUrl, maxCandidates) {
  try {
    const base64Image = await fetchImageAsBase64(imageUrl);
    let cookieState = await ensure1688CookieStateInPlugin();
    if (!cookieState.token) {
      return { success: false, error: "没有拿到 1688 搜图 token，请先在 Chrome 登录 1688.com" };
    }
    try {
      return { success: true, candidates: await collect1688CandidatesInPlugin(base64Image, cookieState, maxCandidates) };
    } catch (e) {
      if (/FAIL_SYS_TOKEN|_m_h5_tk|token|令牌/i.test(e.message || "")) {
        cookieState = await ensure1688CookieStateInPlugin(true);
        if (cookieState.token) {
          return { success: true, candidates: await collect1688CandidatesInPlugin(base64Image, cookieState, maxCandidates) };
        }
      }
      return { success: false, error: e.message || String(e) };
    }
  } catch (e) {
    return { success: false, error: e.message || String(e) };
  }
}

async function collect1688CandidatesInPlugin(base64Image, cookieState, maxCandidates) {
  const imageId = await uploadImageTo1688InPlugin(base64Image, cookieState);
  await sleep(randomInt(1200, 2800));
  const candidates = (await searchOffersByImageIdInPlugin(imageId, cookieState)).slice(0, maxCandidates);
  const enriched = [];
  for (const [index, candidate] of candidates.entries()) {
    if (index > 0) await sleep(randomInt(2500, 6500));
    const details = await scrape1688CandidateDetailsInPlugin(candidate);
    enriched.push(addTrafficBaitAssessmentInPlugin(merge1688CandidateDetailsInPlugin(candidate, details)));
  }
  return enriched;
}

async function fetchImageAsBase64(url) {
  const resp = await fetch(url, { credentials: "omit", headers: { Referer: "https://www.ozon.ru/" } });
  if (!resp.ok) throw new Error(`主图下载失败 ${resp.status}`);
  const buffer = await resp.arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(binary);
}

async function get1688CookieStateInPlugin() {
  const urls = ["https://www.1688.com/", "https://s.1688.com/", "https://m.1688.com/", "https://h5api.m.1688.com/"];
  const map = new Map();
  for (const url of urls) {
    const cookies = await chrome.cookies.getAll({ url }).catch(() => []);
    for (const cookie of cookies) map.set(cookie.name, cookie);
  }
  for (const domain of [".1688.com", "1688.com", ".m.1688.com", "h5api.m.1688.com"]) {
    const cookies = await chrome.cookies.getAll({ domain }).catch(() => []);
    for (const cookie of cookies) map.set(`${cookie.domain}:${cookie.name}`, cookie);
  }
  const tokenCookie = Array.from(map.values()).find((cookie) => cookie.name === "_m_h5_tk");
  const token = tokenCookie?.value?.split("_")[0] || "";
  return {
    token,
    cookieHeader: Array.from(map.values()).map(c => `${c.name}=${c.value}`).join("; "),
  };
}

async function ensure1688CookieStateInPlugin(forceRefresh = false) {
  let state = await get1688CookieStateInPlugin();
  if (state.token && !forceRefresh) return state;
  await seed1688MtopTokenInPlugin().catch((e) => console.warn(`[SW ${VERSION}] 1688 token seed 失败: ${e.message}`));
  state = await get1688CookieStateInPlugin();
  if (state.token && !forceRefresh) return state;
  const tab = await chrome.tabs.create({ url: "https://h5api.m.1688.com/", active: false });
  try {
    await waitForTabComplete(tab.id, 30000).catch(() => {});
    await sleep(2500);
  } finally {
    await safeRemoveTab(tab.id);
  }
  await seed1688MtopTokenInPlugin().catch((e) => console.warn(`[SW ${VERSION}] 1688 token seed retry 失败: ${e.message}`));
  return get1688CookieStateInPlugin();
}

async function seed1688MtopTokenInPlugin() {
  const dataStr = JSON.stringify({ appId: 32517, params: JSON.stringify({ beginPage: 1, pageSize: 1, method: "imageOfferSearchService" }) });
  const timestamp = String(Date.now());
  const url = buildMtopUrlInPlugin({
    t: timestamp,
    sign: signMtopInPlugin("", timestamp, dataStr),
    type: "jsonp",
    callback: "mtopjsonpreqSeed",
    dataType: "jsonp",
    data: dataStr,
  });
  await fetch(url, {
    method: "GET",
    headers: build1688HeadersInPlugin("", { Referer: "https://s.1688.com/" }),
    credentials: "include",
  }).catch(() => null);
  await sleep(600);
}

async function uploadImageTo1688InPlugin(base64Image, cookieState) {
  const uploadParams = {
    appId: 32517,
    params: JSON.stringify({
      beginPage: 1,
      pageSize: 60,
      searchScene: "pcImageSearch",
      method: "uploadBase64WithRequest",
      appName: "pctusou",
      imageBase64: base64Image,
      tab: "imageSearch",
      spm: "a26352.b28411319/2508.imagesearch.upload",
      sortType: "normal",
    }),
  };
  const dataStr = JSON.stringify(uploadParams);
  const timestamp = String(Date.now());
  const url = buildMtopUrlInPlugin({
    t: timestamp,
    sign: signMtopInPlugin(cookieState.token, timestamp, dataStr),
    type: "originaljson",
    dataType: "jsonp",
    jsonpIncPrefix: "reqTppId_32517_getOfferList",
  });
  const resp = await fetch(url, {
    method: "POST",
    headers: build1688HeadersInPlugin(cookieState.cookieHeader, { "Content-Type": "application/x-www-form-urlencoded" }),
    credentials: "include",
    body: `data=${encodeURIComponent(dataStr)}`,
  });
  const json = parseMtopTextInPlugin(await resp.text());
  assertMtopSuccessInPlugin(json, "上传图片失败");
  const imageId = json.data?.data?.imageId || json.data?.imageId || json.data?.result?.[0]?.imageId;
  if (!imageId) throw new Error(`上传成功但没有 imageId: ${JSON.stringify(json).slice(0, 300)}`);
  return imageId;
}

async function searchOffersByImageIdInPlugin(imageId, cookieState) {
  const searchParams = {
    appId: 32517,
    params: JSON.stringify({
      beginPage: 1,
      pageSize: 60,
      method: "imageOfferSearchService",
      searchScene: "pcImageSearch",
      appName: "pctusou",
      tab: "imageSearch",
      imageId,
      imageIdList: imageId,
      sortType: "normal",
    }),
  };
  const dataStr = JSON.stringify(searchParams);
  const timestamp = String(Date.now());
  const url = buildMtopUrlInPlugin({
    t: timestamp,
    sign: signMtopInPlugin(cookieState.token, timestamp, dataStr),
    type: "jsonp",
    callback: "mtopjsonpreqTppId_32517_getOfferList2",
    dataType: "jsonp",
    jsonpIncPrefix: "reqTppId_32517_getOfferList",
    data: dataStr,
  });
  const resp = await fetch(url, {
    method: "GET",
    headers: build1688HeadersInPlugin(cookieState.cookieHeader),
    credentials: "include",
  });
  const json = parseMtopTextInPlugin(await resp.text());
  assertMtopSuccessInPlugin(json, "搜索 1688 失败");
  const offers = json.data?.data?.OFFER?.items || [];
  return offers.map((item, index) => {
    const data = item.data || {};
    const offerId = data.offerId || data.skuId || "";
    const moqItem = Array.isArray(data.afterPriceList)
      ? data.afterPriceList.find((entry) => entry.matKey === "quantity_begin")
      : null;
    const title = data.title || data.subject || "";
    const promotionText = collectPromotionTextFromValueInPlugin(data);
    const pack = inferPackQuantityFromTextInPlugin([title, promotionText].join(" "));
    return {
      rank: index + 1,
      title,
      price: data.priceInfo?.price || data.price || "",
      image: normalizeUrlInPlugin(data.offerPicUrl || data.odPicUrl || data.mainImage || data.picUrl || ""),
      link: normalizeUrlInPlugin(data.linkUrl || data.sameDesignUrl || (offerId ? `https://detail.1688.com/offer/${offerId}.html` : "")),
      shopName: data.shop?.text || data.shopAddition?.text || data.loginId || data.sellerName || "",
      moq: moqItem?.text || "1件起批",
      minOrderQuantity: moqItem?.text || "1件起批",
      promotionText,
      packQuantity: pack.quantity,
      packQuantityEvidence: pack.evidence,
      shippingFee: "",
      dimensionsText: "",
      weightText: "",
      priceDetails: "",
    };
  });
}

async function scrape1688CandidateDetailsInPlugin(candidate) {
  if (!candidate.link) return { detailError: "没有候选链接" };
  const tab = await chrome.tabs.create({ url: candidate.link, active: false });
  try {
    await waitForTabComplete(tab.id, 70000);
    await sleep(randomInt(3500, 8000));
    const [execResult] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extract1688DetailData,
      args: [candidate],
    });
    return execResult?.result || {};
  } catch (e) {
    return { detailError: e.message || String(e) };
  } finally {
    await safeRemoveTab(tab.id);
  }
}

function extract1688DetailData(fallback) {
  const clean = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
  const pick = (...values) => values.map(clean).find(Boolean) || "";
  const unwrap = (value) => (value && typeof value === "object" && value.fields ? value.fields : value);
  const asArray = (value) => (Array.isArray(value) ? value : []);
  const normalizeWeightGrams = (value) => {
    const text = clean(value);
    if (!text) return null;
    const match = text.match(/(\d+(?:[.,]\d+)?)\s*(кг|kg|公斤|千克|килограмм(?:а|ов)?|г|g|克|гр|грамм(?:а|ов)?|мг|mg|毫克)(?=$|[\s,.;，。；、/)\]}])/i);
    if (match) {
      const number = Number(match[1].replace(",", "."));
      const unit = match[2].toLowerCase();
      if (!Number.isFinite(number) || number <= 0) return null;
      if (/^(кг|kg|公斤|千克)|килограмм/i.test(unit)) return Math.round(number * 1000);
      if (/^(мг|mg|毫克)/i.test(unit)) return Math.max(1, Math.round(number / 1000));
      return Math.round(number);
    }
    if (/^\d+(?:[.,]\d+)?$/.test(text)) {
      const number = Number(text.replace(",", "."));
      if (!Number.isFinite(number) || number <= 0) return null;
      if (number < 1) return Math.round(number * 1000);
      if (number < 30 && !Number.isInteger(number)) return Math.round(number * 1000);
      return Math.round(number);
    }
    return null;
  };
  const addPair = (attrs, key, value) => {
    const k = clean(key).replace(/[:：]$/, "");
    const v = clean(value);
    if (k && v && k !== v && k.length <= 80 && v.length <= 300) attrs[k] = v;
  };

  const promotionPattern = /首单|首件|首购|新人|新客|新用户|新人价|新客价|首单价|首单减|首购价|立减|满减|优惠|优惠券|券后|领券|补贴|到手价|特价|限时|促销|专享|折扣|discount|coupon|new\s*user|first\s*order/i;
  const raw = window.__INIT_DATA?.data || window.context?.result?.data || window.iDetailData || {};
  const rawText = document.body?.innerText || "";
  const bodyText = clean(rawText);

  const attrs = {};
  const productAttrs = unwrap(raw.productAttributes || {});
  if (productAttrs?.product_attributes) {
    for (const [key, value] of Object.entries(productAttrs.product_attributes)) addPair(attrs, key, value);
  } else if (productAttrs && typeof productAttrs === "object") {
    for (const [key, value] of Object.entries(productAttrs)) {
      if (typeof value === "string" || typeof value === "number") addPair(attrs, key, value);
    }
  }
  const featureAttrs = raw.offerDetail?.featureAttributes || [];
  if (Array.isArray(featureAttrs)) {
    for (const item of featureAttrs) addPair(attrs, item?.name, item?.value);
  }
  for (const row of document.querySelectorAll("dt")) {
    const dd = row.nextElementSibling;
    if (dd) addPair(attrs, row.innerText, dd.innerText);
  }
  for (const row of document.querySelectorAll("tr")) {
    const cells = Array.from(row.children).map((cell) => clean(cell.innerText)).filter(Boolean);
    if (cells.length >= 2) addPair(attrs, cells[0], cells.slice(1).join(" "));
  }
  const getAttr = (...names) => {
    const normalized = names.map((name) => String(name).toLowerCase());
    for (const [key, value] of Object.entries(attrs)) {
      const lower = key.toLowerCase();
      if (normalized.some((name) => lower.includes(name))) return value;
    }
    return "";
  };

  const mainPrice = unwrap(raw.mainPrice || {});
  const orderParamModel = unwrap(raw.orderParamModel || {});
  const orderParam = orderParamModel.orderParam || {};
  const skuParam = orderParam.skuParam || {};
  const trade = mainPrice.finalPriceModel?.tradeWithoutPromotion || {};
  const priceRanges = [
    ...asArray(skuParam.skuRangePrices),
    ...asArray(trade.offerPriceRanges),
  ].map((item) => ({
    beginAmount: item.beginAmount ?? item.startAmount ?? item.quantity ?? "",
    price: item.price ?? item.discountPrice ?? item.value ?? "",
  })).filter((item) => item.price !== "");

  const skuModel = unwrap(raw.skuModel || raw.rawFusion?.skuSelection || {});
  const skuPrices = Object.values(skuModel.skuInfoMap || {})
    .map((item) => item?.price ?? item?.originalPrice ?? item?.salePrice)
    .filter((value) => value !== undefined && value !== null && value !== "");
  const priceDetails = priceRanges.length
    ? priceRanges.map((item) => `${item.beginAmount || 1}件起 ¥${item.price}`).join("; ")
    : "";
  const rangePrices = priceRanges
    .map((item) => Number(String(item.price).replace(/[^\d.]/g, "")))
    .filter((value) => Number.isFinite(value) && value > 0);
  const minPrice = [...rangePrices, ...skuPrices.map(Number).filter((value) => Number.isFinite(value) && value > 0)]
    .sort((a, b) => a - b)[0];
  const domPrice = bodyText.match(/¥\s*(\d+(?:[.,]\d+)?)/)?.[1] || "";
  const price = pick(minPrice ? String(minPrice) : "", domPrice, /^\s*\d+(?:\.\d+)?\s*$/.test(String(fallback.price || "")) ? fallback.price : "");

  const promotionLines = rawText.split(/\n+/)
    .map(clean)
    .filter((line) => promotionPattern.test(line) && line.length <= 220)
    .slice(0, 16);
  const collectPromotionSnippets = (value, snippets = [], depth = 0) => {
    if (snippets.length >= 24 || depth > 5 || value == null) return snippets;
    if (typeof value === "string" || typeof value === "number") {
      const text = clean(value);
      if (promotionPattern.test(text) && text.length <= 220) snippets.push(text);
    } else if (Array.isArray(value)) {
      for (const item of value.slice(0, 80)) collectPromotionSnippets(item, snippets, depth + 1);
    } else if (typeof value === "object") {
      for (const [key, child] of Object.entries(value).slice(0, 120)) {
        if (promotionPattern.test(key)) snippets.push(clean(`${key}: ${typeof child === "object" ? "" : child}`));
        collectPromotionSnippets(child, snippets, depth + 1);
      }
    }
    return snippets;
  };
  const promotionText = Array.from(new Set([...promotionLines, ...collectPromotionSnippets(raw)].filter(Boolean))).slice(0, 24).join("；");

  const moqFromPriceRange = priceRanges
    .map((item) => Number(item.beginAmount))
    .filter((value) => Number.isFinite(value) && value > 0)
    .sort((a, b) => a - b)[0];
  const moqFromDom = bodyText.match(/(\d+)\s*(?:件|个|只|套|箱|包)\s*起批/);
  const minOrderQuantity = pick(moqFromPriceRange ? `${moqFromPriceRange}件起批` : "", moqFromDom ? `${moqFromDom[1]}件起批` : "", fallback.moq);

  const packInfo = unwrap(raw.productPackInfo || raw.pieceWeightScale || raw.offerDetail?.pieceWeightScale || {});
  const pieceWeightScale = packInfo.pieceWeightScale || packInfo;
  const scaleInfoList = asArray(pieceWeightScale.pieceWeightScaleInfo || packInfo.pieceWeightScaleInfo);
  const columnList = asArray(pieceWeightScale.columnList || packInfo.columnList);
  const colMap = {};
  for (const col of columnList) {
    const label = clean(col.label || col.title || col.name);
    const name = col.name || col.field || col.key;
    if (!name) continue;
    if (/长|length/i.test(label)) colMap.length = name;
    if (/宽|width/i.test(label)) colMap.width = name;
    if (/高|height/i.test(label)) colMap.height = name;
    if (/重|weight/i.test(label)) colMap.weight = name;
  }
  const firstScale = scaleInfoList.find((item) => item && (
    item[colMap.length] || item.length || item[colMap.width] || item.width ||
    item[colMap.height] || item.height || item[colMap.weight] || item.weight
  )) || {};
  const length = pick(firstScale[colMap.length], firstScale.length, firstScale.long, getAttr("长", "length"));
  const width = pick(firstScale[colMap.width], firstScale.width, getAttr("宽", "width"));
  const height = pick(firstScale[colMap.height], firstScale.height, getAttr("高", "height"));
  const attrDimension = getAttr("尺寸", "规格尺寸", "包装尺寸", "产品尺寸");
  const dimensionsText = length || width || height ? `${length || "-"} x ${width || "-"} x ${height || "-"} cm` : attrDimension;

  const shipping = unwrap(raw.shippingServices || {});
  const freightInfo = shipping.freightInfo || {};
  const skuWeight = freightInfo.skuWeight && typeof freightInfo.skuWeight === "object"
    ? Object.values(freightInfo.skuWeight).find(Boolean)
    : "";
  const weightRaw = pick(firstScale[colMap.weight], firstScale.weight, packInfo.unitWeight, shipping.unitWeight, skuWeight, getAttr("重量", "克重", "毛重", "净重", "weight"));
  const weightGrams = normalizeWeightGrams(weightRaw);
  const shippingFee = pick(freightInfo.totalCost, freightInfo.postFeeValue, shipping.totalCost, shipping.postFeeValue, getAttr("运费", "物流费用", "快递费"), /包邮|免运费/.test(rawText) ? "0" : "");
  const title = pick(
    raw.productTitle?.fields?.title,
    raw.productTitle?.title,
    document.querySelector('meta[property="og:title"]')?.content,
    document.querySelector("h1")?.innerText,
    fallback.title,
  );

  return {
    title,
    price,
    priceDetails,
    minOrderQuantity,
    moq: minOrderQuantity,
    shippingFee,
    dimensionsText,
    weightText: weightGrams ? `${weightGrams} g` : "",
    weightGrams,
    promotionText,
    detailAttributes: attrs,
  };
}

function normalize1688PriceOnlyInPage(value) {
  const match = String(value || "").match(/(\d+(?:[.,]\d+)?)/);
  return match ? match[1].replace(",", ".") : "";
}

function buildMtopUrlInPlugin(params) {
  const url = new URL(MTOP_URL);
  const defaults = {
    jsv: "2.7.2",
    appKey: MTOP_APP_KEY,
    api: "mtop.relationrecommend.wirelessrecommend.recommend",
    v: "2.0",
    timeout: "20000",
  };
  for (const [key, value] of Object.entries({ ...defaults, ...params })) {
    if (value !== undefined && value !== null) url.searchParams.set(key, String(value));
  }
  return url.toString();
}

function signMtopInPlugin(token, timestamp, dataStr) {
  return md5(`${token}&${timestamp}&${MTOP_APP_KEY}&${dataStr}`);
}

function build1688HeadersInPlugin(_cookieHeader, extra = {}) {
  return {
    Accept: "application/json,text/plain,*/*",
    Referer: "https://s.1688.com/",
    Origin: "https://s.1688.com",
    ...extra,
  };
}

function parseMtopTextInPlugin(text) {
  try {
    return JSON.parse(text);
  } catch {
    const match = String(text || "").match(/^[^(]*\(([\s\S]*)\)\s*;?$/);
    if (!match) throw new Error(`接口返回不是 JSON：${String(text || "").slice(0, 300)}`);
    return JSON.parse(match[1]);
  }
}

function assertMtopSuccessInPlugin(json, message) {
  const ret = Array.isArray(json?.ret) ? json.ret.join("; ") : "";
  if (!ret.includes("SUCCESS")) {
    throw new Error(`${message}：${ret || JSON.stringify(json).slice(0, 500)}`);
  }
}

function normalizeUrlInPlugin(url) {
  const text = String(url || "").trim();
  if (!text) return "";
  if (text.startsWith("//")) return `https:${text}`;
  if (text.startsWith("/")) return `https://www.1688.com${text}`;
  return text;
}

function collectPromotionTextFromValueInPlugin(value, snippets = [], depth = 0) {
  if (snippets.length >= 24 || depth > 5 || value == null) return snippets.join("；");
  const pattern = /首单|首件|新人|新客|优惠|优惠券|券后|立减|满减|补贴|特价|限时|促销|折扣|discount|coupon/i;
  if (typeof value === "string" || typeof value === "number") {
    const text = String(value).replace(/\s+/g, " ").trim();
    if (pattern.test(text) && text.length <= 220) snippets.push(text);
  } else if (Array.isArray(value)) {
    value.slice(0, 80).forEach(v => collectPromotionTextFromValueInPlugin(v, snippets, depth + 1));
  } else if (typeof value === "object") {
    Object.entries(value).slice(0, 120).forEach(([key, child]) => {
      if (pattern.test(key)) snippets.push(String(key));
      collectPromotionTextFromValueInPlugin(child, snippets, depth + 1);
    });
  }
  return Array.from(new Set(snippets.filter(Boolean))).slice(0, 24).join("；");
}

function inferPackQuantityFromTextInPlugin(text) {
  const body = String(text || "");
  const patterns = [
    /(\d+)\s*(?:шт|pcs|pieces|件|个|只|套|pack|упак)/i,
    /(?:набор|комплект|set)\s*(?:из)?\s*(\d+)/i,
    /(\d+)\s*(?:предмет|штук)/i,
  ];
  for (const pattern of patterns) {
    const match = body.match(pattern);
    const quantity = match ? Number(match[1]) : 0;
    if (quantity > 1 && quantity <= 100) return { quantity, evidence: match[0] };
  }
  return { quantity: 1, evidence: "" };
}

function merge1688CandidateDetailsInPlugin(candidate, details = {}) {
  const detailAttrText = Object.entries(details.detailAttributes || {})
    .map(([key, value]) => `${key}: ${value}`)
    .join(" ");
  const inferredPack = inferPackQuantityFromTextInPlugin([details.title, candidate.title, detailAttrText].join(" "));
  const pack = details.packQuantity || candidate.packQuantity || inferredPack.quantity;
  return {
    ...candidate,
    ...details,
    title: details.title || candidate.title,
    price: normalize1688PriceOnlyInPlugin(details.priceDetails || candidate.priceDetails || details.price || candidate.price),
    minOrderQuantity: details.minOrderQuantity || candidate.minOrderQuantity || candidate.moq,
    moq: details.moq || details.minOrderQuantity || candidate.moq,
    shippingFee: details.shippingFee || candidate.shippingFee || "",
    dimensionsText: details.dimensionsText || candidate.dimensionsText || "",
    weightText: details.weightText || candidate.weightText || "",
    weightGrams: details.weightGrams || candidate.weightGrams || normalizeWeightGramsInPlugin(details.weightText || candidate.weightText),
    priceDetails: details.priceDetails || candidate.priceDetails || "",
    promotionText: [candidate.promotionText, details.promotionText].filter(Boolean).join("；"),
    packQuantity: pack,
    packQuantityEvidence: details.packQuantityEvidence || candidate.packQuantityEvidence || inferredPack.evidence || "",
    detailError: details.detailError || "",
  };
}

function addTrafficBaitAssessmentInPlugin(candidate) {
  const unitPriceRmb = extract1688MinimumTierUnitPriceInPlugin(candidate.priceDetails || candidate.price);
  const values = extractRmbValuesInPlugin([candidate.price, candidate.priceDetails, candidate.minOrderQuantity, candidate.moq].join(" "));
  const positive = values.filter(v => v > 0).sort((a, b) => a - b);
  const minPriceRmb = positive[0] ?? null;
  const maxPriceRmb = positive[positive.length - 1] ?? null;
  const trafficBaitRisk = (minPriceRmb !== null && minPriceRmb < 1) ||
    (minPriceRmb !== null && maxPriceRmb !== null && maxPriceRmb >= 10 && maxPriceRmb / Math.max(minPriceRmb, 0.01) >= 10);
  return {
    ...candidate,
    price: unitPriceRmb !== null ? formatPriceNumberInPlugin(unitPriceRmb) : normalize1688PriceOnlyInPlugin(candidate.price || candidate.priceDetails),
    unitPriceRmb,
    minPriceRmb,
    maxPriceRmb,
    trafficBaitRisk,
    trafficBaitReason: trafficBaitRisk ? "价格过低或价格跨度异常，可能是引流 SKU" : "",
    avoidForSourcing: trafficBaitRisk,
  };
}

function normalize1688PriceOnlyInPlugin(value) {
  const tier = extract1688MinimumTierUnitPriceInPlugin(value);
  if (tier !== null) return formatPriceNumberInPlugin(tier);
  const match = String(value || "").match(/(\d+(?:[.,]\d+)?)/);
  return match ? match[1].replace(",", ".") : "";
}

function extract1688MinimumTierUnitPriceInPlugin(value) {
  const values = extractRmbValuesInPlugin(value);
  const positive = values.filter(v => v > 0).sort((a, b) => a - b);
  return positive.length ? positive[0] : null;
}

function extractRmbValuesInPlugin(value) {
  const matches = String(value || "").matchAll(/(?:¥|￥)?\s*(\d+(?:[.,]\d+)?)/g);
  return Array.from(matches).map(m => Number(m[1].replace(",", "."))).filter(Number.isFinite);
}

function normalizeWeightGramsInPlugin(value) {
  const text = String(value || "");
  const match = text.match(/(\d+(?:[.,]\d+)?)\s*(kg|公斤|千克|кг|g|克|г|гр)/i);
  if (!match) return null;
  const n = Number(match[1].replace(",", "."));
  if (!Number.isFinite(n)) return null;
  return /kg|公斤|千克|кг/i.test(match[2]) ? Math.round(n * 1000) : Math.round(n);
}

function formatPriceNumberInPlugin(value) {
  const n = Number(value);
  return Number.isFinite(n) ? String(Number(n.toFixed(2))) : "";
}

function md5(input) {
  function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
  function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
  function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
  function md5cycle(x, k) {
    let [a, b, c, d] = x;
    a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586);
    c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
    a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426);
    c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
    a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417);
    c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
    a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101);
    c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
    a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632);
    c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
    a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083);
    c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
    a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690);
    c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
    a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784);
    c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
    a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463);
    c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
    a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353);
    c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
    a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222);
    c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
    a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835);
    c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
    a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415);
    c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
    a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606);
    c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
    a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744);
    c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
    a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379);
    c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
    x[0] = add32(a, x[0]); x[1] = add32(b, x[1]); x[2] = add32(c, x[2]); x[3] = add32(d, x[3]);
  }
  function md5blk(s) { const a = []; for (let i = 0; i < 64; i += 4) a[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) + (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24); return a; }
  function md51(s) {
    const n = s.length; const state = [1732584193, -271733879, -1732584194, 271733878]; let i;
    for (i = 64; i <= n; i += 64) md5cycle(state, md5blk(s.substring(i - 64, i)));
    s = s.substring(i - 64);
    const tail = Array(16).fill(0);
    for (i = 0; i < s.length; i++) tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
    tail[i >> 2] |= 0x80 << ((i % 4) << 3);
    if (i > 55) { md5cycle(state, tail); tail.fill(0); }
    tail[14] = n * 8;
    md5cycle(state, tail);
    return state;
  }
  function rhex(n) { let s = ""; for (let j = 0; j < 4; j++) s += ((n >> (j * 8 + 4)) & 0x0f).toString(16) + ((n >> (j * 8)) & 0x0f).toString(16); return s; }
  function hex(x) { return x.map(rhex).join(""); }
  function add32(a, b) { return (a + b) & 0xffffffff; }
  return hex(md51(unescape(encodeURIComponent(String(input)))));
}

function looksLikeRichContentDoc(raw) {
  const doc = parseMaybeJsonForSyntheticRich(raw);
  return Boolean(
    doc &&
    typeof doc === "object" &&
    !Array.isArray(doc) &&
    Array.isArray(doc.content) &&
    doc.content.some(block => block && typeof block === "object" && typeof block.widgetName === "string")
  );
}

function parseMaybeJsonForSyntheticRich(value) {
  if (typeof value !== "string") return value;
  const trimmed = value.trim();
  if (!trimmed || !/^[\[{]/.test(trimmed)) return value;
  try { return JSON.parse(trimmed); } catch { return value; }
}

function synthesizeRichContentFromImages(images) {
  const urls = [];
  const seen = new Set();
  const normalize = (raw) => {
    const url = String(raw || "").trim().split(/[?#]/)[0];
    if (!/^https?:\/\//i.test(url)) return "";
    if (/\/wc\d+\//i.test(url)) return "";
    if (!/(ir-\d+\.ozonru\.cn|ir\.ozone\.ru)\/s3\/multimedia/i.test(url)) return "";
    return url;
  };
  const keyFor = (url) => {
    try {
      const parsed = new URL(url);
      const path = decodeURIComponent(parsed.pathname || "").replace(/\/wc\d+\//gi, "/");
      return (path.split("/").filter(Boolean).pop() || path).toLowerCase();
    } catch {
      return String(url || "").toLowerCase();
    }
  };
  for (const raw of Array.isArray(images) ? images : []) {
    const url = normalize(raw);
    if (!url) continue;
    const key = keyFor(url);
    if (seen.has(key)) continue;
    seen.add(key);
    urls.push(url);
    if (urls.length >= 8) break;
  }
  if (!urls.length) return "";
  const block = (src) => ({
    imgLink: "",
    img: {
      src,
      srcMobile: src,
      alt: "",
      position: "width_full",
      positionMobile: "width_full",
      widthMobile: 800,
      heightMobile: 800,
    },
  });
  const content = [{
    widgetName: "raShowcase",
    type: "billboard",
    blocks: [block(urls[0])],
  }];
  if (urls.length > 1) {
    content.push({
      widgetName: "raShowcase",
      type: "roll",
      blocks: urls.slice(1).map(block),
    });
  }
  return JSON.stringify({
    content,
    version: 0.3,
  });
}

function ensureSyntheticRichContent(data) {
  if (!data || typeof data !== "object") return false;
  const existing = typeof data.richContent === "string" ? data.richContent.trim() : "";
  if (existing && looksLikeRichContentDoc(existing)) return false;
  const rich = synthesizeRichContentFromImages(data.images);
  if (!rich) return false;
  data.richContent = rich;
  data._synthetic_rich_content = true;
  if (data._debug && typeof data._debug === "object") {
    data._debug.syntheticRichContentBytes = rich.length;
    if (!Array.isArray(data._debug.attributeSources)) data._debug.attributeSources = [];
    data._debug.attributeSources.push("rich-content.11254.synthetic-images");
  }
  return true;
}

// ========== v2.2.9.15: Seller Portal 复制商品源包 ==========
// My ERP 批量跟卖实际不是只读公开 PDP，而是先 /api/v1/search 找 variant_id，
// 再调 /api/site/seller-prototype/create-bundle-by-variant-id 拿完整 bundle item。
async function getSellerCompanyId() {
  const readCookieValue = (cookies) => String((cookies || []).find(c => c?.name === "sc_company_id" && c?.value)?.value || "").trim();

  // v2.2.9.19: Chrome 有时按 url 读不到 sc_company_id，但按 name 或页面 document.cookie 能读到。
  // My ERP 也会从 seller 页面 cookie 兜底；这里保持一致，避免已登录却误报未登录。
  let value = readCookieValue(await chrome.cookies.getAll({ url: "https://seller.ozon.ru/", name: "sc_company_id" }));
  if (value) return value;

  value = readCookieValue(await chrome.cookies.getAll({ name: "sc_company_id" }));
  if (value) return value;

  const tabs = await chrome.tabs.query({ url: ["https://seller.ozon.ru/*", "https://*.ozon.ru/*"] }).catch(() => []);
  const sellerTabs = [
    ...tabs.filter(t => /^https:\/\/seller\.ozon\.ru\//i.test(t.url || "")),
    ...tabs.filter(t => /^https:\/\/([^/]+\.)?ozon\.ru\//i.test(t.url || "") && !/^https:\/\/seller\.ozon\.ru\//i.test(t.url || "")),
  ];
  for (const tab of sellerTabs) {
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: () => {
          const m = String(document.cookie || "").split(";").map(s => s.trim()).find(s => s.startsWith("sc_company_id="));
          return m ? decodeURIComponent(m.slice("sc_company_id=".length)) : "";
        },
      });
      value = String(res?.result || "").trim();
      if (value) return value;
    } catch {}
  }
  return "";
}

async function fetchSellerPortalViaOzonTab(path, body, opts = {}) {
  const timeoutMs = opts.timeoutMs || 30000;
  const urlPrefix = opts.urlPrefix !== undefined ? opts.urlPrefix : "/api/v1";
  const preferTabId = opts.preferTabId || null;
  const isOzonUrl = (u) => /^https?:\/\/([^/]+\.)?ozon\.ru\//i.test(u || "");
  let target = null;
  if (preferTabId) {
    try {
      const t = await chrome.tabs.get(preferTabId);
      if (t && isOzonUrl(t.url)) target = t;
    } catch {}
  }
  if (!target) {
    const tabs = await chrome.tabs.query({ url: ["*://*.ozon.ru/*"] });
    target = tabs.find(t => t.status === "complete" && t.active)
      || tabs.find(t => t.status === "complete")
      || tabs[0]
      || null;
  }
  if (!target) throw new Error("无可用 ozon.ru 标签页，无法调用 seller portal");

  const doFetch = async (apiPath, reqBody, timeout, prefix) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const resp = await fetch("https://seller.ozon.ru" + (prefix || "/api/v1") + apiPath, {
        method: "POST",
        credentials: "include",
        signal: controller.signal,
        headers: { "content-type": "text/plain" },
        body: JSON.stringify(reqBody || {}),
      });
      clearTimeout(timer);
      if (resp.redirected && /\/(signin|login)/i.test(resp.url || "")) {
        return { ok: false, status: 401, error: "seller 登录态已过期，请重新登录 seller.ozon.ru" };
      }
      const text = await resp.text();
      let json = null;
      try { json = text ? JSON.parse(text) : null; } catch {}
      if (!resp.ok) {
        return { ok: false, status: resp.status, error: `Seller portal HTTP ${resp.status}: ${text.slice(0, 300)}` };
      }
      return { ok: true, data: json };
    } catch (e) {
      clearTimeout(timer);
      return { ok: false, error: e.name === "AbortError" ? `请求超时 (${timeout}ms)` : (e.message || String(e)) };
    }
  };

  const results = await chrome.scripting.executeScript({
    target: { tabId: target.id },
    func: doFetch,
    args: [path, body, timeoutMs, urlPrefix],
    world: "MAIN",
  });
  const r = results?.[0]?.result;
  if (!r) throw new Error("seller portal executeScript 未返回结果");
  if (!r.ok) throw new Error(r.error || "seller portal 请求失败");
  return r.data;
}

function clonePlain(value) {
  return JSON.parse(JSON.stringify(value || null));
}

async function portalCreateBundle(companyId, preferTabId) {
  const resp = await fetchSellerPortalViaOzonTab("/seller-prototype/create-bundle", {
    company_id: String(companyId),
  }, { urlPrefix: "/api/site", timeoutMs: 30000, preferTabId });
  const bundleId = resp?.bundle_id;
  if (!bundleId) throw new Error("Seller portal create-bundle 未返回 bundle_id");
  return String(bundleId);
}

async function portalUpdateBundleItems(bundleId, companyId, items, preferTabId) {
  return fetchSellerPortalViaOzonTab("/seller-prototype/update-bundle-items", {
    bundle_id: String(bundleId),
    company_id: String(companyId),
    source: "SOURCE_MERGED",
    description_category_lvl3_name: "",
    items,
  }, { urlPrefix: "/api/site", timeoutMs: 60000, preferTabId });
}

async function portalUploadBundle(bundleId, companyId, preferTabId) {
  const resp = await fetchSellerPortalViaOzonTab("/seller-prototype/upload-bundle", {
    bundle_id: String(bundleId),
    company_id: String(companyId),
    strict: true,
  }, { urlPrefix: "/api/site", timeoutMs: 60000, preferTabId });
  const taskId = resp?.upload_task_id || resp?.task_id;
  if (!taskId) throw new Error("Seller portal upload-bundle 未返回 upload_task_id");
  return String(taskId);
}

function ensurePortalAttr(item, attributeId, values) {
  const id = String(attributeId);
  if (!Array.isArray(item.attributes)) item.attributes = [];
  const normalizedValues = (Array.isArray(values) ? values : [values])
    .filter(v => v !== undefined && v !== null && String(v).trim() !== "")
    .map((v, idx) => ({
      value: String(v).trim(),
      sequence: String(idx),
      is_default: idx === 0,
      complex_sequence: "0",
      dictionary_value_id: "0",
    }));
  if (!normalizedValues.length) return;
  const existing = item.attributes.find(a => String(a?.attribute_id || a?.id || "") === id && String(a?.complex_id || "0") === "0");
  if (existing) {
    existing.values = normalizedValues;
  } else {
    item.attributes.push({ attribute_id: id, complex_id: "0", values: normalizedValues });
  }
}

function normalizePortalAttributes(item, opts = {}) {
  const removeIds = new Set((opts.removeIds || []).map(id => String(id)));
  const attrs = Array.isArray(item?.attributes) ? item.attributes : [];
  const byKey = new Map();
  for (const attr of attrs) {
    const id = String(attr?.attribute_id ?? attr?.id ?? "").trim();
    if (!id || removeIds.has(id)) continue;
    const complexId = String(attr?.complex_id ?? "0");
    const key = `${id}:${complexId}`;
    if (!byKey.has(key)) {
      byKey.set(key, attr);
      continue;
    }
    const current = byKey.get(key);
    const currentValues = Array.isArray(current?.values) ? current.values : [];
    const nextValues = Array.isArray(attr?.values) ? attr.values : [];
    if (!currentValues.length && nextValues.length) byKey.set(key, attr);
  }
  item.attributes = Array.from(byKey.values());
}

function buildPortalItemFromImportItem(importItem) {
  if (!importItem || typeof importItem !== "object") throw new Error("portalImport 缺少 item");
  const sourceVariant = importItem._sourceVariant && typeof importItem._sourceVariant === "object" ? importItem._sourceVariant : null;
  const sourceBundleItem = sourceVariant?._bundleItem && typeof sourceVariant._bundleItem === "object" ? sourceVariant._bundleItem : null;
  if (!sourceBundleItem) throw new Error("portalImport 需要 Seller bundle 源包 (_sourceVariant._bundleItem)");

  const item = clonePlain(sourceBundleItem);
  const images = Array.isArray(importItem.images) ? importItem.images.filter(u => typeof u === "string" && /^https?:\/\//i.test(u)) : [];
  item.id = "0";
  item.item_id = "0";
  item.sku = "0";
  item.deleted = false;
  item.unmerged = false;
  item.offer_id = String(importItem.offer_id || "").trim();
  item.name = String(importItem.name || item.name || "").replace(/\s+/g, " ").trim().slice(0, 200);
  item.price = String(importItem.price || item.price || "");
  item.old_price = String(importItem.old_price || item.old_price || importItem.price || "");
  item.currency = String(importItem.currency_code || importItem.currency || item.currency || "CNY");
  item.description_category_id = String(importItem.description_category_id || item.description_category_id || sourceVariant.description_category_id || "");
  item.new_description_category_id = "0";
  item.weight = Number(importItem.weight || item.weight || 0);
  item.depth = Number(importItem.depth || item.depth || 0);
  item.width = Number(importItem.width || item.width || 0);
  item.height = Number(importItem.height || item.height || 0);
  item.barcode = String(importItem.barcode || item.barcode || "");
  if (images.length) {
    item.images = images;
    item.primary_image = images[0];
  }
  if (item.name) ensurePortalAttr(item, 4180, item.name);
  if (item.weight) ensurePortalAttr(item, 4497, item.weight);
  if (item.depth) ensurePortalAttr(item, 9454, item.depth);
  if (item.width) ensurePortalAttr(item, 9455, item.width);
  if (item.height) ensurePortalAttr(item, 9456, item.height);
  if (item.barcode) ensurePortalAttr(item, 23524, item.barcode);
  if (importItem.richContent) ensurePortalAttr(item, 11254, importItem.richContent);
  // 图片在 seller-prototype bundle 里走 top-level images/primary_image。
  // 同时带 4194/4195 会被 Ozon 判定“图片字段重复”。
  normalizePortalAttributes(item, { removeIds: [4194, 4195] });
  return item;
}

async function portalImportItems(importItems, preferTabId) {
  const companyId = await getSellerCompanyId();
  if (!companyId) throw new Error("未找到 sc_company_id cookie，请确认 seller.ozon.ru 已登录并选中目标店铺");
  const items = (Array.isArray(importItems) ? importItems : [importItems]).map(buildPortalItemFromImportItem);
  if (!items.length) throw new Error("portalImport 没有可提交商品");
  const bundleId = await portalCreateBundle(companyId, preferTabId);
  await portalUpdateBundleItems(bundleId, companyId, items, preferTabId);
  const taskId = await portalUploadBundle(bundleId, companyId, preferTabId);
  return {
    viaPortal: true,
    company_id: companyId,
    bundle_id: bundleId,
    task_id: taskId,
    upload_task_id: taskId,
    items: items.map(i => ({ offer_id: i.offer_id, name: i.name, image: i.primary_image || (i.images || [])[0] || "" })),
  };
}

function normalizeSearchVariantToSv(v) {
  if (!v) return null;
  if (Array.isArray(v.attributes) && v.attributes.length > 0) return v;
  const attributes = [];
  if (v.description_type_name) attributes.push({ key: "8229", value: v.description_type_name });
  if (v.brand_name) attributes.push({ key: "85", value: v.brand_name });
  const productName = v.variant_name || v.title || v.name;
  if (productName) attributes.push({ key: "4180", value: productName });
  if (v.description) attributes.push({ key: "4191", value: v.description });
  if (v.main_image) attributes.push({ key: "4194", value: v.main_image });
  const secondaries = Array.isArray(v.secondary_images) ? v.secondary_images : [];
  if (secondaries.length > 0) attributes.push({ key: "4195", collection: secondaries });
  if (Array.isArray(v.barcodes) && v.barcodes.length > 0) {
    const gtin = String(v.barcodes[0] || "").trim();
    if (gtin) attributes.push({ key: "7822", value: gtin });
  }
  const categories = (v.categories || []).map(c => ({
    id: Number(c.id),
    level: Number(c.level),
    name: c.name || "",
    title: c.title || c.name || "",
  })).filter(c => c.id);
  return {
    variant_id: v.variant_id || (v.barcodes && v.barcodes[0]) || "",
    type_id: Number(v.description_type_dict_value) || 0,
    description_category_id: categories.length ? Number(categories[categories.length - 1].id) : 0,
    categories,
    _searchMeta: {
      skus: v.skus || [],
      barcodes: v.barcodes || [],
      brand_id: v.brand_id,
      is_copy_allowed: v.is_copy_allowed,
      is_content_copy_allowed: v.is_content_copy_allowed,
      rating: v.rating,
    },
    attributes,
  };
}

function addSourceAttr(attrs, key, value, extra = {}) {
  if (value === undefined || value === null || value === "") return;
  const exists = attrs.some(a => String(a?.key ?? a?.id ?? a?.attribute_id) === String(key));
  if (exists) return;
  attrs.push({ key: String(key), value: String(value), ...extra });
}

function readBundleAttrValues(attr) {
  const vals = Array.isArray(attr?.values) ? attr.values : [];
  return vals
    .map(v => v && typeof v === "object" ? (v.value ?? v.text ?? v.name ?? "") : v)
    .map(v => String(v || "").trim())
    .filter(Boolean);
}

function buildSourceVariantFromBundle(searchSv, bundleItem) {
  const sv = searchSv && typeof searchSv === "object" ? { ...searchSv } : { attributes: [] };
  const attrs = Array.isArray(sv.attributes) ? [...sv.attributes] : [];
  const existing = new Set(attrs.map(a => String(a?.key ?? a?.id ?? a?.attribute_id)));

  if (Number(bundleItem?.weight) > 0 && !existing.has("4497")) { attrs.push({ key: "4497", value: String(bundleItem.weight) }); existing.add("4497"); }
  if (Number(bundleItem?.depth) > 0 && !existing.has("9454")) { attrs.push({ key: "9454", value: String(bundleItem.depth) }); existing.add("9454"); }
  if (Number(bundleItem?.width) > 0 && !existing.has("9455")) { attrs.push({ key: "9455", value: String(bundleItem.width) }); existing.add("9455"); }
  if (Number(bundleItem?.height) > 0 && !existing.has("9456")) { attrs.push({ key: "9456", value: String(bundleItem.height) }); existing.add("9456"); }
  if (bundleItem?.barcode && !existing.has("7822")) { attrs.push({ key: "7822", value: String(bundleItem.barcode) }); existing.add("7822"); }

  const bundleComplexAttrs = [];
  if (Array.isArray(bundleItem?.attributes)) {
    for (const ba of bundleItem.attributes) {
      if (ba?.complex_id && String(ba.complex_id) !== "0") {
        bundleComplexAttrs.push(ba);
        continue;
      }
      const key = String(ba?.attribute_id || ba?.id || "");
      if (!key || existing.has(key)) continue;
      const vals = readBundleAttrValues(ba);
      if (!vals.length) continue;
      const rawValues = Array.isArray(ba.values)
        ? ba.values
            .filter(v => v && v.value != null && String(v.value).trim() !== "")
            .map(v => ({
              value: String(v.value).trim(),
              ...(Number(v.dictionary_value_id || 0) > 0 ? { dictionary_value_id: Number(v.dictionary_value_id) } : {}),
            }))
        : [];
      const attr = { key, ...(rawValues.length ? { values: rawValues } : {}) };
      if (vals.length > 1) attr.collection = vals;
      else attr.value = vals[0];
      const dictId = Number(ba?.values?.[0]?.dictionary_value_id || ba?.dictionary_value_id || 0);
      if (dictId > 0 && vals.length === 1) attr.dictionary_value_id = dictId;
      attrs.push(attr);
      existing.add(key);
    }
  }

  sv.attributes = attrs;
  if (bundleComplexAttrs.length) sv._bundleComplexAttrs = bundleComplexAttrs;
  sv._bundleItem = bundleItem;
  return sv;
}

function sourceVariantToFlatAttributes(sourceVariant, currentAttrs) {
  const attrs = Array.isArray(currentAttrs) ? [...currentAttrs] : [];
  const existing = new Set(attrs.map(a => String(a?.id ?? a?.attribute_id ?? a?.key ?? "")));
  for (const a of (sourceVariant?.attributes || [])) {
    const id = Number(a?.id ?? a?.attribute_id ?? a?.key);
    if (!Number.isFinite(id) || id <= 0 || existing.has(String(id))) continue;
    let value = "";
    if (Array.isArray(a.collection)) value = a.collection.map(v => String(v || "").trim()).filter(Boolean).join(", ");
    else if (a.value !== undefined && a.value !== null) value = String(a.value);
    else if (Array.isArray(a.values)) value = readBundleAttrValues(a).join(", ");
    if (!value) continue;
    attrs.push({ id, name: a.name || "", value, ...(a.dictionary_value_id ? { dictionary_value_id: Number(a.dictionary_value_id) } : {}) });
    existing.add(String(id));
  }
  return attrs;
}

function extractImagesFromSourceVariant(sourceVariant) {
  const images = [];
  const push = (u) => {
    if (typeof u === "string" && /^https?:\/\//i.test(u) && !images.includes(u)) images.push(u);
  };
  const attrs = Array.isArray(sourceVariant?.attributes) ? sourceVariant.attributes : [];
  const get = (key) => attrs.find(a => String(a?.key ?? a?.id ?? a?.attribute_id) === String(key));
  const primary = get("4194");
  if (primary?.value) push(primary.value);
  const gallery = get("4195");
  if (Array.isArray(gallery?.collection)) gallery.collection.forEach(push);
  if (gallery?.value) push(gallery.value);
  const bundle = sourceVariant?._bundleItem || {};
  push(bundle.primary_image);
  for (const img of (Array.isArray(bundle.images) ? bundle.images : [])) push(typeof img === "string" ? img : (img?.file_name || img?.url || img?.src));
  return images;
}

function parseMaybeJsonForSellerBundle(value) {
  if (typeof value !== "string") return value;
  const trimmed = value.trim();
  if (!trimmed || !/^[\[{]/.test(trimmed)) return value;
  try { return JSON.parse(trimmed); } catch { return value; }
}

function isSellerBundleRichContentDoc(doc) {
  return Boolean(
    doc &&
    typeof doc === "object" &&
    !Array.isArray(doc) &&
    Array.isArray(doc.content) &&
    doc.content.length > 0 &&
    doc.content.some(block => block && typeof block === "object" && typeof block.widgetName === "string" && block.widgetName.trim())
  );
}

function scoreSellerBundleRichContent(doc, json) {
  let widgetCount = 0;
  let textChars = 0;
  let imageCount = 0;
  const skipKeys = new Set(["widgetName", "align", "size", "color", "type", "src", "srcMobile", "url", "link", "imgLink", "richAnnotationJson", "style", "trackingInfo"]);
  const walk = (node, key, depth) => {
    if (node == null || depth > 24) return;
    if (typeof node === "string") {
      const text = node.replace(/\s+/g, " ").trim();
      if (!skipKeys.has(key) && text.length > 2 && !/^https?:\/\//i.test(text) && /[A-Za-zА-Яа-яЁё]/.test(text)) textChars += text.length;
      if (/^https?:\/\/.+\.(?:jpg|jpeg|png|webp|gif|avif)(?:[?#].*)?$/i.test(text)) imageCount += 1;
      return;
    }
    if (Array.isArray(node)) { for (const item of node) walk(item, key, depth + 1); return; }
    if (typeof node !== "object") return;
    if (node.widgetName) widgetCount += 1;
    for (const childKey of Object.keys(node)) walk(node[childKey], childKey, depth + 1);
  };
  walk(doc.content, "content", 0);
  return widgetCount * 1000 + textChars * 20 + imageCount * 30 + Math.min(String(json || "").length, 20000) / 20000;
}

function extractRichContentFromSellerBundleStates(states) {
  if (!states || typeof states !== "object") return "";
  const candidates = [];
  const seenJson = new Set();
  const seenObjects = typeof WeakSet !== "undefined" ? new WeakSet() : null;
  const addCandidate = (doc, rawJson) => {
    if (!isSellerBundleRichContentDoc(doc)) return;
    const json = typeof rawJson === "string" && rawJson.trim()
      ? rawJson.trim()
      : JSON.stringify({ content: doc.content, version: doc.version || 0.3 });
    if (seenJson.has(json)) return;
    seenJson.add(json);
    candidates.push({ json, score: scoreSellerBundleRichContent(doc, json) - candidates.length / 1000 });
  };
  const walk = (node, depth) => {
    if (node == null || depth > 28) return;
    const parsed = parseMaybeJsonForSellerBundle(node);
    if (!parsed || typeof parsed !== "object") return;
    if (seenObjects) {
      if (seenObjects.has(parsed)) return;
      seenObjects.add(parsed);
    }
    if (typeof parsed.richAnnotationJson === "string" && parsed.richAnnotationJson.trim()) {
      addCandidate(parseMaybeJsonForSellerBundle(parsed.richAnnotationJson), parsed.richAnnotationJson);
    }
    if (isSellerBundleRichContentDoc(parsed)) addCandidate(parsed, null);
    if (Array.isArray(parsed)) {
      for (const item of parsed) walk(item, depth + 1);
      return;
    }
    for (const key of Object.keys(parsed)) walk(parsed[key], depth + 1);
  };
  walk(states, 0);
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0]?.json || "";
}

async function enrichFromSellerPortalBundle(data, sku, preferTabId) {
  const companyId = await getSellerCompanyId();
  if (!companyId) throw new Error("未找到 sc_company_id cookie，请确认 seller.ozon.ru 已登录并选中店铺");
  const searchResp = await fetchSellerPortalViaOzonTab("/search", {
    company_id: String(companyId),
    need_total: true,
    filter: {
      children_nodes: {
        children_nodes: [{ input_leaf: { sku: { values: [String(sku)] } } }],
        operator: "AND",
      },
    },
    pagination: { limit: "50" },
    is_copy_allowed: false,
  }, { urlPrefix: "/api/v1", timeoutMs: 30000, preferTabId });

  const rawVariants = Array.isArray(searchResp?.variants) ? searchResp.variants
    : Array.isArray(searchResp?.items) ? searchResp.items
    : Array.isArray(searchResp?.products) ? searchResp.products
    : Array.isArray(searchResp) ? searchResp : [];
  const sv = rawVariants.map(normalizeSearchVariantToSv).find(Boolean);
  if (!sv?.variant_id) {
    throw new Error(`Seller /search 未找到 SKU ${sku} 的 variant_id (variants=${rawVariants.length})`);
  }

  const bundleResp = await fetchSellerPortalViaOzonTab("/seller-prototype/create-bundle-by-variant-id", {
    company_id: String(companyId),
    variant_id: String(sv.variant_id),
    source: "SOURCE_UI_COPY_APPAREL",
  }, { urlPrefix: "/api/site", timeoutMs: 30000, preferTabId });
  const bundleItem = bundleResp?.item || null;
  if (!bundleItem) {
    throw new Error(`Seller create-bundle-by-variant-id 未返回 item (variant_id=${sv.variant_id})`);
  }
  if (!Array.isArray(bundleItem.attributes) || bundleItem.attributes.length === 0) {
    throw new Error(`Seller bundle 返回空 attributes (variant_id=${sv.variant_id}, bundle_id=${bundleResp?.bundle_id || ""})`);
  }

  const sourceVariant = buildSourceVariantFromBundle(sv, bundleItem);
  data._sourceVariant = sourceVariant;
  data.attributes = sourceVariantToFlatAttributes(sourceVariant, data.attributes);
  const bundleRichContent = extractRichContentFromSellerBundleStates(bundleResp) || extractRichContentFromSellerBundleStates(bundleItem);
  if (bundleRichContent && !data.richContent) {
    data.richContent = bundleRichContent;
  }
  const images = extractImagesFromSourceVariant(sourceVariant);
  if (images.length) {
    data.images = [...images, ...(Array.isArray(data.images) ? data.images : [])].filter((u, idx, arr) => u && arr.indexOf(u) === idx).slice(0, 15);
    data.primary_image = data.images[0] || data.primary_image || "";
  }
  if (bundleItem.name && !data.name) data.name = String(bundleItem.name);
  if (bundleItem.description && !data.description) data.description = String(bundleItem.description);
  if (Number(bundleItem.weight) > 0) data.weight = Number(bundleItem.weight);
  if (Number(bundleItem.depth) > 0) data.depth = Number(bundleItem.depth);
  if (Number(bundleItem.width) > 0) data.width = Number(bundleItem.width);
  if (Number(bundleItem.height) > 0) data.height = Number(bundleItem.height);
  if (bundleItem.barcode) data.barcode = String(bundleItem.barcode);
  const sellerTypeId = Number(sv.type_id || sourceVariant?.type_id || 0);
  const sellerCategoryId = Number(sv.description_category_id || sourceVariant?.description_category_id || 0);
  if (sellerTypeId > 0) data.type_id = sellerTypeId;
  if (sellerCategoryId > 0) data.description_category_id = sellerCategoryId;
  data._seller_bundle_source = {
    company_id: String(companyId),
    variant_id: String(sv.variant_id),
    bundle_id: bundleResp?.bundle_id || null,
    attr_count: Array.isArray(bundleItem.attributes) ? bundleItem.attributes.length : 0,
    type_id: sellerTypeId || null,
    description_category_id: sellerCategoryId || null,
  };
  return { attrCount: data.attributes.length, imageCount: data.images.length };
}

// ========== v2.1: Ozon Seller API (OPI) 辅源 ==========
const storeProductsCache = new Map();  // storeId -> { products, ts, credsMasked }
const CACHE_TTL_MS = 5 * 60 * 1000;     // 5 分钟

// 通用 OPI fetch 封装 (仿 0.13.48.1 opi-client.js)
async function callOpi(path, body, creds) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  try {
    const res = await fetch(`${OPI_BASE_URL}${path}`, {
      method: "POST",
      headers: {
        "Client-Id": String(creds.clientId),
        "Api-Key": String(creds.apiKey),
        "Content-Type": "application/json",
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
    const text = await res.text();
    let parsed = null;
    try { parsed = text ? JSON.parse(text) : null; } catch {}
    if (!res.ok) {
      throw new Error(`OPI ${res.status} ${path}: ${(text||"").slice(0, 200)}`);
    }
    return parsed;
  } finally {
    clearTimeout(timer);
  }
}

// 从 ERP 后端拿店铺凭证
async function getStoreCreds(storeId) {
  const url = `${ERP_BACKEND_ORIGIN}/api/extension/seller-credentials?store_id=${encodeURIComponent(storeId)}`;
  const resp = await fetch(url, { credentials: "include" });
  if (!resp.ok) throw new Error(`getStoreCreds HTTP ${resp.status}`);
  const data = await resp.json();
  if (!data.success) throw new Error(data.error || "no creds");
  return { clientId: data.clientId, apiKey: data.apiKey, storeName: data.storeName };
}

// 列店铺所有已上架商品 (带缓存)
async function listStoreProducts(storeId, creds, force = false) {
  const cached = storeProductsCache.get(storeId);
  if (!force && cached && Date.now() - cached.ts < CACHE_TTL_MS) {
    return cached.products;
  }
  const all = [];
  let lastId = "";
  for (let i = 0; i < 10; i++) {  // 最多 10 页 = 10000 商品
    const resp = await callOpi("/v3/product/list", {
      filter: { visibility: "ALL" },
      limit: 1000,
      last_id: lastId,
    }, creds);
    const items = resp?.result?.items || [];
    all.push(...items);
    lastId = resp?.result?.last_id || "";
    if (!lastId || items.length < 1000) break;
  }
  storeProductsCache.set(storeId, { products: all, ts: Date.now() });
  return all;
}

// 找相似商品: 同类目优先, 否则 name 相似度匹配
function findSimilarProduct(products, sourceName, sourceCategoryId) {
  if (!products.length) return null;
  // 1) 类目完全匹配优先
  const sameCat = products.filter(p => p.description_category_id === sourceCategoryId);
  if (sameCat.length === 1) return sameCat[0];
  if (sameCat.length > 1 && sourceName) {
    const lower = sourceName.toLowerCase();
    const tokens = lower.split(/\s+/).filter(t => t.length >= 3).slice(0, 5);
    let best = null; let bestScore = 0;
    for (const p of sameCat) {
      const pName = (p.name || "").toLowerCase();
      let score = 0;
      for (const t of tokens) if (pName.includes(t)) score++;
      if (score > bestScore) { bestScore = score; best = p; }
    }
    if (best && bestScore > 0) return best;
  }
  // 2) 无类目匹配, 退化到 name 相似
  if (sourceName) {
    const lower = sourceName.toLowerCase();
    const tokens = lower.split(/\s+/).filter(t => t.length >= 4).slice(0, 3);
    let best = null; let bestScore = 0;
    for (const p of products) {
      const pName = (p.name || "").toLowerCase();
      let score = 0;
      for (const t of tokens) if (pName.includes(t)) score++;
      if (score > bestScore) { bestScore = score; best = p; }
    }
    if (best && bestScore >= 2) return best;
  }
  return null;
}

// 拿商品的 attributes (含 type_id / description_category_id)
async function getProductInfo(offerId, creds) {
  const resp = await callOpi("/v3/product/info", { offer_id: offerId }, creds);
  return resp?.result || resp;
}

// v2.1 主入口: 用 OPI 给公开页采集的 data 补 attributes + 修正 type/cat
async function enrichFromOpi(data, storeId) {
  console.log(`[SW ${VERSION}]   OPI 辅源: 拿凭证 (store=${storeId})...`);
  const creds = await getStoreCreds(storeId);
  // v2.1.8 兜底: 即使没找到相似商品, 用 SKU 直接反查自己店铺有没有同款
  //   (跟卖场景中同 SKU 通常已发布过), 拿到 type_id / attributes 兜底补齐
  try {
    const own = await getProductInfo(String(data.sku || ""), creds);
    if (own && typeof own === "object" && !data._seller_bundle_enriched) {
      data._sourceVariant = own;
    }
    if (own && own.type_id && !data.type_id) {
      data.type_id = own.type_id;
      data._source_type_id = "opi-direct-sku-lookup";
      console.log(`[SW ${VERSION}]   OPI 直查 SKU 拿到 type_id=${own.type_id}`);
    }
    if (own && Array.isArray(own.attributes) && own.attributes.length && (!data.attributes || !data.attributes.length)) {
      data.attributes = mapOpiAttributes(own.attributes, data.attributes || []);
      data._source_attributes = "opi-direct-sku-lookup";
      console.log(`[SW ${VERSION}]   OPI 直查 SKU 拿到 ${own.attributes.length} 个 attributes`);
    }
  } catch (e) {
    console.log(`[SW ${VERSION}]   OPI 直查 SKU 失败 (非致命): ${e.message}`);
  }
  console.log(`[SW ${VERSION}]   OPI 辅源: 拿 ${creds.storeName} 商品列表...`);
  const products = await listStoreProducts(storeId, creds);
  console.log(`[SW ${VERSION}]   OPI 辅源: 店铺有 ${products.length} 个商品, 找类目 ${data.description_category_id} 的同款...`);
  const similar = findSimilarProduct(products, data.name, data.description_category_id);
  if (!similar) {
    console.log(`[SW ${VERSION}]   OPI 辅源: 未找到同款 (类目=${data.description_category_id}, name="${data.name?.slice(0,30)}")`);
    return null;
  }
  console.log(`[SW ${VERSION}]   OPI 辅源: 找到 ${similar.offer_id} (${similar.name?.slice(0,30)})`);
  const detail = await getProductInfo(similar.offer_id, creds);
  if (!detail) return null;
  if (!data._seller_bundle_enriched) data._sourceVariant = detail;
  // 合并 attributes
  const opiAttrs = detail.attributes || [];
  if (!opiAttrs.length) {
    console.log(`[SW ${VERSION}]   OPI 辅源: ${similar.offer_id} 没有 attributes, 跳过合并`);
    return null;
  }
  // 初始化
  if (!data.attributes) data.attributes = [];
  const _mr = mapOpiAttributes(opiAttrs, data.attributes);
  data.attributes = _mr.attrs;
  const added = _mr.added;
  const overridden = _mr.overridden;
  // 修正 type_id (OPI 更准)
  if (detail.type_id && !data.type_id) {
    data.type_id = detail.type_id;
  }
  // 修正 description_category_id (OPI 精确)
  if (detail.description_category_id && detail.description_category_id !== data.description_category_id) {
    console.log(`[SW ${VERSION}]   OPI 修正 cat: ${data.description_category_id} → ${detail.description_category_id}`);
    data.description_category_id = detail.description_category_id;
  }
  // 记录来源
  data._opi_source = similar.offer_id;
  return { added, overridden };
}

// ========== v2.1.9+: 通过 ERP 后端解析 Seller 类目 (替换不可靠的 URL 解析) ==========
// v2.3.0+: 带 type_id + candidates
// v2.2.9.3: 加 name 参数, 让 server 端 candidates 能用 name 关键词从 Ozon 全 tree 过滤
async function resolveSellerCategory(sku, storeId, typeId, breadcrumbCatId, name) {
  if ((!sku && !typeId) || !storeId) return null;
  try {
    const ctrl = new AbortController();
    // v2.2.9.17: 首次加载 Ozon category tree 时服务端可能需要 18-25s。
    // 之前 15s 会先 abort，导致后端明明算出 candidates，前端仍显示“未解析”。
    const timer = setTimeout(() => ctrl.abort(), 45000);
    const res = await fetch(`${ERP_BACKEND_ORIGIN}/api/seller/products/category-resolve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        sku: Number(sku) || 0,
        store_id: storeId,
        type_id: Number(typeId) || 0,
        breadcrumb_cat_id: Number(breadcrumbCatId) || 0,  // 5位 URL breadcrumb (v2.2.9)
        name: String(name || '').trim(),  // v2.2.9.3: 让 server 端用 name 关键词匹配 Ozon tree
      }),
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    console.warn(`[SW ${VERSION}]   resolveSellerCategory 失败 (非致命): ${e.message}`);
    return null;
  }
}

// 等待 tab 状态变成 complete
function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    const t0 = Date.now();
    const check = async () => {
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab.status === "complete") {
          // 再额外等 2s 让 JS 渲染 (Ozon 是 SPA, status=complete 后还有异步加载)
          setTimeout(resolve, 2000);
          return;
        }
        if (Date.now() - t0 > timeoutMs) {
          reject(new Error(`tab status=${tab.status}, 超时 ${timeoutMs}ms`));
          return;
        }
        setTimeout(check, 500);
      } catch (e) {
        reject(e);
      }
    };
    check();
  });
}

async function safeRemoveTab(tabId) {
  try {
    await chrome.tabs.remove(tabId);
  } catch (e) {
    // tab 已关闭, 忽略
  }
}

// ========== 注入到 Ozon 商品页的提取函数 (IIFE) ==========
// 这个函数被 executeScript 注入到 www.ozon.ru 商品页, 在 page context 跑
// v1.0.9 大幅扩展: 把上架需要的全部字段都尝试从页面拿到
async function extractOzonProductData(sku) {
  // v2.2.9.10 (fix): 把整个提取逻辑包 try/catch, helper 函数必须在 closure 里
  //   chrome.scripting.executeScript 注入的函数只能引用自己函数体内代码 (跨函数调 ReferenceError)
  try {
    // ========== 内嵌 helper 函数 (必须在 closure 里) ==========
function deepFindFullProduct(obj, sku, depth) {
  if (depth > 10 || !obj || typeof obj !== "object") return null;
  // 命中条件: 同时有 description_category_id + images + name
  if (typeof obj.description_category_id === "number" &&
      typeof obj.type_id === "number" &&
      obj.name &&
      Array.isArray(obj.images)) {
    return { source: `obj.sku=${obj.sku || "?"}`, object: obj };
  }
  // 备选命中: 只有 description_category_id + type_id + name
  if (typeof obj.description_category_id === "number" &&
      typeof obj.type_id === "number" &&
      obj.name &&
      (Array.isArray(obj.attributes) || Array.isArray(obj.complex_attributes))) {
    return { source: `obj.sku=${obj.sku || "?"} (partial)`, object: obj };
  }
  // 遍历
  for (const key of Object.keys(obj)) {
    const result = deepFindFullProduct(obj[key], sku, depth + 1);
    if (result) {
      result.source = `${key}.${result.source}`;
      return result;
    }
  }
  return null;
}

function mergeProductObject(data, obj) {
  if (!obj) return;
  // 基础字段
  if (obj.name && !data.name) data.name = String(obj.name).trim();
  if (obj.sku && !data.offer_id) data.offer_id = String(obj.sku);
  if (obj.id && !data.product_id) data.product_id = String(obj.id);
  if (obj.barcode && !data.barcode) data.barcode = String(obj.barcode);
  if (obj.description && !data.description) data.description = String(obj.description);
  if (obj.brand && !data.brand) {
    data.brand = typeof obj.brand === "string" ? obj.brand : (obj.brand?.name || "");
  }
  if (obj.description_category_id && !data.description_category_id) data.description_category_id = obj.description_category_id;
  if (obj.type_id && !data.type_id) data.type_id = obj.type_id;
  if (obj.vat) data.vat = String(obj.vat);
  if (obj.currency_code) data.currency_code = String(obj.currency_code);
  if (obj.weight && !data.weight) {
    const w = parseWeight(obj.weight);
    if (w) data.weight = w;
  }
  if (obj.country_of_origin && !data.country_of_origin) data.country_of_origin = String(obj.country_of_origin);

  // 尺寸 (Ozon 有时是 dimensions 对象)
  if (obj.dimensions) {
    if (obj.dimensions.depth && !data.depth) data.depth = parseInt(obj.dimensions.depth, 10) || 0;
    if (obj.dimensions.width && !data.width) data.width = parseInt(obj.dimensions.width, 10) || 0;
    if (obj.dimensions.height && !data.height) data.height = parseInt(obj.dimensions.height, 10) || 0;
  }

  // 图片 (Ozon 格式: [{url, ...}] 或 [{file_name, ...}])
  if (Array.isArray(obj.images)) {
    for (const img of obj.images) {
      const url = typeof img === "string" ? img : (img.url || img.file_name || img.src);
      addImageUrl(data, url);
    }
  }
  if (obj.image) {
    const imgs = Array.isArray(obj.image) ? obj.image : [obj.image];
    for (const img of imgs) addImageUrl(data, typeof img === "string" ? img : (img.url || img.src || img.file_name));
  }
  if (obj.primary_image) addImageUrl(data, obj.primary_image);
  if (obj.cover_image) addImageUrl(data, obj.cover_image);
  if (obj.color_image) addImageUrl(data, obj.color_image);

  // Attributes 数组 (Ozon 格式: [{id, name, values: [{value}]}])
  if (Array.isArray(obj.attributes)) {
    for (const attr of obj.attributes) {
      const id = attr.id || attr.attribute_id;
      const name = attr.name || attr.title || "";
      let value = "";
      let dictionary_value_id = 0;
      if (Array.isArray(attr.values) && attr.values.length > 0) {
        value = typeof attr.values[0] === "string" ? attr.values[0] : (attr.values[0]?.value || attr.values[0]?.text || "");
        dictionary_value_id = Number(attr.values[0]?.dictionary_value_id || attr.values[0]?.id || 0);
      } else if (attr.value) {
        value = String(attr.value);
      }
      if (name && value) {
        const key = `${id || name}:${value}`;
        if (!data._attrKeys.has(key)) {
          data.attributes.push({ id, name, value, ...(dictionary_value_id > 0 ? { dictionary_value_id } : {}) });
          data._attrKeys.add(key);
        }
      }
    }
  }

  // complex_attributes (Ozon 格式可能不同, 原样保留)
  if (Array.isArray(obj.complex_attributes) && data.complex_attributes.length === 0) {
    data.complex_attributes = obj.complex_attributes;
  }
}

function parseWeight(w) {
  if (typeof w === "number") return Math.round(w);
  if (typeof w === "string") {
    const m = w.match(/^([\d.]+)\s*(g|kg|г|克)?$/i);
    if (m) {
      const val = parseFloat(m[1]);
      const unit = (m[2] || "g").toLowerCase();
      if (unit === "kg") return Math.round(val * 1000);
      return Math.round(val);
    }
  }
  if (typeof w === "object" && w.value) {
    return parseWeight(w.value);
  }
  return 0;
}

function normalizeImageUrl(url) {
  if (!url || typeof url !== "string") return "";
  let s = url.trim()
    .replace(/\\u002F/g, "/")
    .replace(/\\\//g, "/")
    .replace(/&amp;/g, "&");
  if (s.startsWith("//")) s = "https:" + s;
  if (!/^https?:\/\//i.test(s)) return "";
  if (!/(ozone\.ru|ozonusercontent\.com|ozonru\.cn)/i.test(s)) return "";
  if (/\.(svg|gif)(?:[?#]|$)/i.test(s)) return "";
  if (/(logo|sprite|icon|avatar|placeholder|transparent|empty)/i.test(s)) return "";
  s = s.split("?")[0];
  s = s.replace(/\/wc\d+\//i, "/wc1000/");
  return s;
}

function addImageUrl(data, url) {
  const normalized = normalizeImageUrl(url);
  if (!normalized) return false;
  if (data._imageKeys.has(normalized)) return false;
  data.images.push(normalized);
  data._imageKeys.add(normalized);
  return true;
}

function collectImagesDeep(data, obj, depth) {
  if (depth > 8 || !obj) return;
  if (typeof obj === "string") {
    addImageUrl(data, obj);
    return;
  }
  if (Array.isArray(obj)) {
    for (const item of obj) {
      if (data.images.length >= 60) return;
      collectImagesDeep(data, item, depth + 1);
    }
    return;
  }
  if (typeof obj !== "object") return;
  for (const [key, value] of Object.entries(obj)) {
    if (data.images.length >= 60) return;
    if (/image|img|photo|picture|gallery|media|cover|src|url|file/i.test(key)) {
      collectImagesDeep(data, value, depth + 1);
    } else if (depth < 4 && value && typeof value === "object") {
      collectImagesDeep(data, value, depth + 1);
    }
  }
}

function collectImagesFromText(data, text) {
  if (!text || typeof text !== "string") return 0;
  const before = data.images.length;
  const normalizedText = text.replace(/\\u002F/g, "/").replace(/\\\//g, "/");
  const re = /(?:https?:)?\/\/(?:ir(?:-\d+)?\.ozonru\.cn|ir\.ozone\.ru|cdn1\.ozone\.ru|[^"'<>\s()]+ozonusercontent\.com)\/[^"'<>\s()\\]+/gi;
  let m;
  while ((m = re.exec(normalizedText)) && data.images.length < 80) {
    addImageUrl(data, m[0]);
  }
	  return data.images.length - before;
	}

function parseMaybeJson(value) {
  if (typeof value !== "string") return value;
  const trimmed = value.trim();
  if (!trimmed || !/^[\[{]/.test(trimmed)) return value;
  try { return JSON.parse(trimmed); } catch { return value; }
}

function isRichContentDoc(doc) {
  return Boolean(
    doc &&
    typeof doc === "object" &&
    !Array.isArray(doc) &&
    Array.isArray(doc.content) &&
    doc.content.length > 0 &&
    doc.content.some(block => block && typeof block === "object" && typeof block.widgetName === "string" && block.widgetName.trim())
  );
}

function collectRichContentStats(doc) {
  const stats = { widgetCount: 0, textWidgetCount: 0, layoutWidgetCount: 0, chessWidgetCount: 0, imageCount: 0, textNodeCount: 0, textChars: 0, hasRealText: false };
  const skipTextKeys = new Set(["widgetName", "align", "size", "color", "type", "src", "srcMobile", "url", "link", "imgLink", "richAnnotationJson", "class", "className", "style", "trackingInfo", "layoutTrackingInfo", "gifUrl", "videoUrl", "previewUrl", "backgroundColor", "theme", "padding", "margin", "id", "reff", "fontColor", "borderColor", "position", "positionMobile"]);
  const looksLikeImageUrl = (text) => /^https?:\/\/.+\.(?:jpg|jpeg|png|webp|gif|avif)(?:[?#].*)?$/i.test(text);
  const pushText = (value, key) => {
    if (key && skipTextKeys.has(key)) return;
    const text = String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    if (text.length < 2 || /^https?:\/\//i.test(text) || looksLikeImageUrl(text)) return;
    if (!/[A-Za-zА-Яа-яЁё]/.test(text)) return;
    stats.textNodeCount += 1;
    stats.textChars += text.length;
  };
  const walk = (node, key, depth) => {
    if (node == null || depth > 24) return;
    if (typeof node === "string") { pushText(node, key); return; }
    if (Array.isArray(node)) { for (const item of node) walk(item, key, depth + 1); return; }
    if (typeof node !== "object") return;
    const widgetName = String(node.widgetName || "");
    const type = String(node.type || "");
    if (widgetName) {
      stats.widgetCount += 1;
      if (/text|description|annotation/i.test(widgetName)) stats.textWidgetCount += 1;
      if (/chess/i.test(widgetName) || /chess/i.test(type)) stats.chessWidgetCount += 1;
      if (/showcase|billboard|roll|tile|media|chess/i.test(widgetName) || /billboard|roll|chess|tile/i.test(type)) stats.layoutWidgetCount += 1;
    }
    if (node.img && typeof node.img === "object") stats.imageCount += 1;
    for (const imageKey of ["src", "srcMobile", "url", "image", "imageUrl", "coverImage"]) {
      const raw = node[imageKey];
      if (typeof raw === "string" && /^https?:\/\//i.test(raw) && looksLikeImageUrl(raw)) stats.imageCount += 1;
    }
    for (const childKey of Object.keys(node)) {
      if (skipTextKeys.has(childKey) && childKey !== "text" && childKey !== "title") continue;
      walk(node[childKey], childKey, depth + 1);
    }
  };
  walk(doc?.content, "content", 0);
  stats.hasRealText = stats.textChars >= 12 || stats.textNodeCount >= 2 || stats.textWidgetCount > 0;
  return stats;
}

function extractRichContentFromStates(states) {
  if (!states || typeof states !== "object") return "";
  const candidates = [];
  const seenJson = new Set();
  const seenObjects = typeof WeakSet !== "undefined" ? new WeakSet() : null;
  const addCandidate = (doc, rawJson) => {
    if (!isRichContentDoc(doc)) return;
    const json = typeof rawJson === "string" && rawJson.trim()
      ? rawJson.trim()
      : JSON.stringify({ content: doc.content, version: doc.version || 0.3 });
    if (seenJson.has(json)) return;
    seenJson.add(json);
    const stats = collectRichContentStats(doc);
    candidates.push({
      json,
      score:
        (stats.hasRealText ? 100000 : 0) +
        stats.chessWidgetCount * 20000 +
        stats.textWidgetCount * 12000 +
        stats.layoutWidgetCount * 600 +
        stats.textChars * 40 +
        stats.textNodeCount * 500 +
        stats.widgetCount * 80 +
        stats.imageCount * 20 +
        Math.min(json.length, 20000) / 20000 -
        candidates.length / 1000,
    });
  };
  const walk = (node, depth) => {
    if (node == null || depth > 24) return;
    const parsed = parseMaybeJson(node);
    if (!parsed || typeof parsed !== "object") return;
    if (seenObjects) {
      if (seenObjects.has(parsed)) return;
      seenObjects.add(parsed);
    }
    if (typeof parsed.richAnnotationJson === "string" && parsed.richAnnotationJson.trim()) {
      addCandidate(parseMaybeJson(parsed.richAnnotationJson), parsed.richAnnotationJson);
    }
    if (isRichContentDoc(parsed)) addCandidate(parsed, null);
    if (Array.isArray(parsed)) {
      for (const item of parsed) walk(item, depth + 1);
      return;
    }
    for (const key of Object.keys(parsed)) walk(parsed[key], depth + 1);
  };
  walk(states, 0);
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0]?.json || "";
}

function normalizeOzonProductInnerPath(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  try {
    const url = new URL(raw, "https://www.ozon.ru");
    return (url.pathname || "") + (url.search || "");
  } catch {
    const noHash = raw.split("#")[0];
    return noHash.startsWith("/") ? noHash : `/${noHash}`;
  }
}

function ozonProductPathKey(value) {
  return normalizeOzonProductInnerPath(value).split("?")[0].replace(/\/+$/, "");
}

function ozonProductIdFromPath(value) {
  const match = ozonProductPathKey(value).match(/\/product\/(?:[^/?#]*-)?(\d+)$/i);
  return match ? match[1] : "";
}

function collectOzonRichContentPagePaths(states, currentPath) {
  const out = [];
  const seenPaths = new Set();
  const seenObjects = typeof WeakSet !== "undefined" ? new WeakSet() : null;
  const currentProductKey = ozonProductPathKey(currentPath);
  const currentProductId = ozonProductIdFromPath(currentPath);
  const push = (candidate) => {
    const pagePath = normalizeOzonProductInnerPath(candidate);
    if (!pagePath || !/[?&]layout_container=pdpPage2column(?:&|$)/.test(pagePath)) return;
    const productKey = ozonProductPathKey(pagePath);
    const productId = ozonProductIdFromPath(pagePath);
    if (currentProductId && productId && currentProductId !== productId) return;
    if ((!currentProductId || !productId) && currentProductKey && productKey && productKey !== currentProductKey) return;
    if (seenPaths.has(pagePath)) return;
    seenPaths.add(pagePath);
    out.push(pagePath);
  };
  const walk = (node, depth) => {
    if (node == null || depth > 18) return;
    const parsed = parseMaybeJson(node);
    if (!parsed || typeof parsed !== "object") return;
    if (seenObjects) {
      if (seenObjects.has(parsed)) return;
      seenObjects.add(parsed);
    }
    if (typeof parsed.nextPage === "string") push(parsed.nextPage);
    if (Array.isArray(parsed)) {
      for (const item of parsed) walk(item, depth + 1);
      return;
    }
    for (const key of Object.keys(parsed)) walk(parsed[key], depth + 1);
  };
  walk(states, 0);
  return out;
}

function richContentHasText(raw) {
  const doc = parseMaybeJson(raw);
  return isRichContentDoc(doc) && collectRichContentStats(doc).hasRealText;
}

async function collectRichContentFromOzonPage(sku) {
  const currentPath = normalizeOzonProductInnerPath(`${location.pathname}${location.search || ""}`);
  const cleanPath = normalizeOzonProductInnerPath(location.pathname);
  const skuPath = sku ? `/product/${sku}/` : "";
  const paths = [currentPath, cleanPath, skuPath].filter(Boolean);
  const endpoints = [];
  const seenEndpoints = new Set();
  const enqueuePath = (path) => {
    const normalized = normalizeOzonProductInnerPath(path);
    if (!normalized) return;
    for (const url of [
      `/api/entrypoint-api.bx/page/json/v2?url=${encodeURIComponent(normalized)}`,
      `/api/composer-api.bx/page/json/v2?url=${encodeURIComponent(normalized)}`,
    ]) {
      if (seenEndpoints.has(url)) continue;
      seenEndpoints.add(url);
      endpoints.push(url);
    }
  };
  for (const path of paths) enqueuePath(path);
  let best = "";
  let bestHasText = false;
  let okCount = 0;
  for (let i = 0; i < endpoints.length; i += 1) {
    const url = endpoints[i];
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const resp = await fetch(url, {
        credentials: "include",
        headers: { "x-o3-app-name": "dweb_client", "accept": "application/json" },
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (!resp.ok) continue;
      okCount += 1;
      const payload = await resp.json();
      const states = payload?.widgetStates || {};
      // Ozon occasionally moves rich-content widgets or pagination hints outside
      // widgetStates. Scan the full page json as a fallback so we do not miss
      // 11254 when the public PDP shape changes.
      for (const root of [states, payload]) {
        for (const nextPage of collectOzonRichContentPagePaths(root, currentPath || cleanPath || skuPath)) enqueuePath(nextPage);
      }
      const rich = extractRichContentFromStates(states) || extractRichContentFromStates(payload);
      if (rich) {
        const hasText = richContentHasText(rich);
        if (!best || (!bestHasText && hasText) || (hasText === bestHasText && rich.length > best.length)) {
          best = rich;
          bestHasText = hasText;
        }
      }
    } catch (e) {
      clearTimeout(timer);
    }
  }
  if (best) console.log(`[zhumeng-extract] rich content 11254 found bytes=${best.length} text=${bestHasText} endpointsOk=${okCount}/${endpoints.length}`);
  else console.warn(`[zhumeng-extract] rich content 11254 not found endpointsOk=${okCount}/${endpoints.length}`);
  return best;
}


    // ========== 主提取逻辑 ==========

  const data = {
    sku: String(sku || ""),
    name: "",
    offer_id: "",
    product_id: "",
    images: [],
    primary_image: "",
    weight: 0,
    depth: 0,
    width: 0,
    height: 0,
    dimension_unit: "mm",
    weight_unit: "g",
    barcode: "",
    description: "",
    description_category_id: 0,
    type_id: 0,
    brand: "",
    currency_code: "RUB",
    vat: "0",
    price: "",
    country_of_origin: "",
	    attributes: [],            // [{id, name, value}] - 上架需要
	    complex_attributes: [],     // 复杂属性
	    raw_url: location.href,
	    _imageKeys: new Set(),
	    _attrKeys: new Set(),
	  };

  const dbg = {
    title: document.title,
    h1Text: document.querySelector('h1')?.textContent?.slice(0, 100) || "",
    imageCount: 0,
    hasLdJson: 0,
    bodyHtmlLength: document.body?.innerHTML?.length || 0,
    breadcrumbLinks: [],
    stateFound: null,
    categoryFromUrl: 0,
    fullStateObject: null,       // v1.0.9 新增: 找到的完整商品 state 对象
    attributeSources: [],
  };

  // ========== 1. URL 路径提取 category_id ==========
  try {
    const m = location.href.match(/\/category\/[^\/?#]*?(\d{2,})(?:\/|\?|#|$)/);
    if (m) {
      data.description_category_id = parseInt(m[1], 10);
      dbg.categoryFromUrl = data.description_category_id;
    }
  } catch (e) {}

  // ========== 2. 面包屑链接提取 category_id ==========
  // v2.2.9.1: 用最后一级 breadcrumb (具体类目), 不是第一个匹配 (顶层类目)
  //   Ozon 商品页 breadcrumb 顺序: 大类 → 中类 → 小类 → 当前 cat
  //   比如 茶壶: Дом и сад(14500) → Посуда(14501) → Чайники(30814) → Заварочные(14534) ← 这个
  const breadcrumbSelectors = [
    '[data-widget="breadCrumbs"] a',
    '[data-widget="webBreadcrumb"] a',
    'ol.breadcrumb a, ol[itemtype*="BreadcrumbList"] a',
    'nav[aria-label*="eadcrumb" i] a',
    'a[href*="/category/"]',
  ];
  const breadcrumbIds = [];  // 按 DOM 顺序收集
  for (const sel of breadcrumbSelectors) {
    const links = document.querySelectorAll(sel);
    for (const a of links) {
      const href = a.href || "";
      if (!href.includes("/category/")) continue;
      dbg.breadcrumbLinks.push(href);
      const m = href.match(/\/category\/[^\/?#]*?(\d{2,})(?:\/|\?|#|$)/);
      if (m) {
        const id = parseInt(m[1], 10);
        if (id && id > 1000) breadcrumbIds.push(id);
      }
    }
    if (breadcrumbIds.length >= 2) break;  // 拿到 2+ 个就够了
  }
  // 关键: 取最后一个 (最具体的, 就是当前商品的 cat)
  if (breadcrumbIds.length) {
    data.description_category_id = breadcrumbIds[breadcrumbIds.length - 1];
    dbg.breadcrumbIdsFound = breadcrumbIds;
    dbg.categoryFromBreadcrumb = data.description_category_id;
  }

  // ========== 3. JSON-LD (schema.org/Product + BreadcrumbList) ==========
  try {
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    dbg.hasLdJson = ldScripts.length;
    for (const s of ldScripts) {
      try {
        const ld = JSON.parse(s.textContent);
        const items = Array.isArray(ld) ? ld : [ld];
        for (const item of items) {
          if (item["@type"] === "Product" || (Array.isArray(item["@type"]) && item["@type"].includes("Product"))) {
            if (item.name && !data.name) data.name = String(item.name).trim();
            if (item.description && !data.description) data.description = String(item.description).trim();
            if (item.gtin13 || item.gtin) data.barcode = String(item.gtin13 || item.gtin);
            if (item.mpn) data.offer_id = String(item.mpn);
            if (item.sku) data.sku = String(item.sku);
            if (item.brand) {
              if (typeof item.brand === "string") data.brand = item.brand;
              else if (item.brand.name) data.brand = item.brand.name;
            }
            if (item.image) {
              const imgs = Array.isArray(item.image) ? item.image : [item.image];
              for (const img of imgs) {
	                addImageUrl(data, img);
	              }
	            }
            if (item.weight) {
              const w = parseWeight(item.weight);
              if (w) data.weight = w;
            }
          }
          if (item["@type"] === "BreadcrumbList" && Array.isArray(item.itemListElement)) {
            for (const bc of item.itemListElement) {
              const url = bc.item?.url || bc.url;
              if (url && url.includes("/category/")) {
                const m = url.match(/\/category\/[^\/?#]*?(\d{2,})(?:\/|\?|#|$)/);
                if (m) {
                  const id = parseInt(m[1], 10);
                  if (id && id > 1000 && !data.description_category_id) {
                    data.description_category_id = id;
                  }
                }
              }
            }
          }
        }
      } catch (e) {}
    }
  } catch (e) {}

  // ========== 4. Ozon 内部 SSR state 深度搜索 (v1.0.9 加强: 找整个商品对象) ==========
  try {
    const stateContainers = [
      () => window.__pinia__?.state?.value,
      () => window.__INITIAL_STATE__,
      () => window.__NUXT__?.state,
      () => window.__NUXT__,
      () => window.__APP__,
      () => window.__NEXT_DATA__?.props,
      () => window.__INITIAL_DATA__,
    ];
	    for (const getter of stateContainers) {
	      try {
	        const state = getter();
	        if (!state) continue;
	        const beforeImages = data.images.length;
	        collectImagesDeep(data, state, 0);
	        if (data.images.length > beforeImages) {
	          dbg.attributeSources.push(`state-images.+${data.images.length - beforeImages}`);
	        }
	        const found = deepFindFullProduct(state, sku, 0);
	        if (found) {
          dbg.stateFound = found.source;
          dbg.fullStateObject = found.object;  // 整个对象, 方便后续处理
          // 把 found.object 里的所有相关字段填充到 data
          mergeProductObject(data, found.object);
          dbg.attributeSources.push(`state.${found.source}`);
          break;
	    }
	  } catch (e) {}

	  // ========== 4.5. 直接扫所有 script 文本里的 Ozon 图片 URL ==========
	  // Ozon 的轮播图经常藏在 hydration JSON / widget state 里, 首屏 DOM 只渲染 1 张.
	  try {
	    let scriptAdded = 0;
	    const scripts = Array.from(document.scripts || []);
	    for (const s of scripts) {
	      const text = s.textContent || "";
	      if (!text || !/(ozone\.ru|ozonusercontent\.com|ozonru\.cn|multimedia|images)/i.test(text)) continue;
	      scriptAdded += collectImagesFromText(data, text);
	      if (data.images.length >= 80) break;
	    }
	    if (scriptAdded > 0) dbg.attributeSources.push(`script-images.+${scriptAdded}`);
	  } catch (e) {}
    }
  } catch (e) {}

  // ========== 5. DOM 提取 (兜底 + 补充) ==========
  if (!data.name) {
    const h1 = document.querySelector('h1');
    if (h1) data.name = h1.textContent.trim();
  }
  if (!data.name) {
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) data.name = ogTitle.getAttribute("content") || "";
  }

	  const beforeDomImages = data.images.length;
	  document.querySelectorAll('img[src*="ozonusercontent"], img[src*="cdn1.ozone"], img[src*="ozone.ru"], source[srcset*="ozon"], source[srcset*="ozone"]').forEach((img) => {
	    const srcs = [
	      img.src,
	      img.dataset?.src,
	      img.getAttribute("data-src"),
	      img.getAttribute("srcset"),
	      img.getAttribute("data-srcset"),
	    ].filter(Boolean);
	    for (const src of srcs) {
	      String(src).split(",").forEach(part => addImageUrl(data, part.trim().split(/\s+/)[0]));
	    }
	  });
	  const ogImage = document.querySelector('meta[property="og:image"]');
	  if (ogImage) addImageUrl(data, ogImage.getAttribute("content"));
	  if (data.images.length > beforeDomImages) {
	    dbg.attributeSources.push(`DOM-images.+${data.images.length - beforeDomImages}`);
	  }
	  data.primary_image = data.images[0] || "";
	  dbg.imageCount = data.images.length;

  // ========== 6. 提取价格 ==========
  if (!data.price) {
    const priceSelectors = [
      '[data-widget="webPrice"] [class*="price"]',
      '[data-widget="finalPrice"] [class*="price"]',
      '[itemprop="price"]',
      '[data-widget="price"]',
      '.price-block [class*="final"]',
    ];
    for (const sel of priceSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        const text = (el.textContent || el.getAttribute("content") || "").trim();
        const m = text.match(/(\d[\d\s]*)/);
        if (m) {
          data.price = m[1].replace(/\s/g, "");
          dbg.attributeSources.push(`price.${sel}`);
          break;
        }
      }
    }
  }

  // ========== 7. 提取 attributes 列表 (Ozon "Характеристики" 区块) ==========
  // Ozon 商品页的属性通常是 div 容器里, key:value 形式
  if (data.attributes.length === 0) {
    // 尝试多种 Ozon 属性区块 selector
    const attributeContainerSelectors = [
      '[data-widget="webCharacteristics"]',
      '[data-widget="characteristics"]',
      'div[class*="characteristics"]',
      'div[id*="characteristics"]',
    ];
    for (const sel of attributeContainerSelectors) {
      const container = document.querySelector(sel);
      if (container) {
        // 找所有 key-value 对
        const rows = container.querySelectorAll('[class*="row"], [class*="item"], dl > div, tr');
        for (const row of rows) {
          const kEl = row.querySelector('[class*="name"], [class*="key"], dt, th, span:first-child');
          const vEl = row.querySelector('[class*="value"], [class*="val"], dd, td, span:last-child');
          if (kEl && vEl) {
            const name = kEl.textContent.trim();
            const value = vEl.textContent.trim();
            if (name && value && name !== value && value.length < 200) {
              data.attributes.push({ name, value });
            }
          }
        }
        if (data.attributes.length > 0) {
          dbg.attributeSources.push(`DOM.${sel}`);
          break;
        }
      }
    }
  }

  // ========== 8. 提取 brand (DOM 兜底) ==========
  if (!data.brand) {
    const brandEl = document.querySelector('[data-widget="webBrand"] a, [class*="brand"] a, [itemprop="brand"]');
    if (brandEl) {
      data.brand = brandEl.textContent.trim();
      dbg.attributeSources.push(`brand.DOM`);
    }
  }

  // ========== 8.5 v2.2.9.5+: attribute 9048 (Название модели) 自动兜底 ==========
  //   Ozon /v3/product/import 接受商品 (imported) 但 attribute 9048 空的话, 商品在 seller 后台无法正常上架
  //   公开页 attributes 没抓到时, 从商品 name 自动提取型号名称
  //   规则: 跳过通用词 (тент/большой/туристический/... + 尺寸/容量/颜色等), 取剩下的英文品牌词段
  //   例: 'Большой туристический тент Cloud Skies Tarp Lite (L), 500х380 см' → 'Cloud Skies Tarp Lite (L)'
  if (!data.attributes.some(a => a.id === 9048)) {
    let model = "";
    if (data.name) {
      // 1) 取第一个逗号前的主段 (去掉尺寸/容量/颜色等后缀)
      const mainPart = data.name.split(",")[0].trim();
      // 2) 过滤掉通用俄文词 (帐篷/旅行/大型/参数等), 剩下的英文+数字+括号当型号
      const tokens = mainPart.split(/\s+/);
      const genericRu = /^(большой|маленький|туристический|походный|складной|детский|зимний|летний|домашний|уличный|портативный|новый|оригинальный|универсальный|легкий|тяжелый)$/i;
      const kept = tokens.filter(t => {
        if (genericRu.test(t)) return false;
        // 跳过纯俄文长词 (形容词)
        if (/^[А-Яа-яЁё]{4,}$/.test(t) && !/[A-Za-z]/.test(t)) return false;
        // 跳过纯数字 / 数字+单位
        if (/^\d+([.,]\d+)?$/.test(t)) return false;
        if (/^\d+\s*(см|мм|м|г|кг|л|мл|w|wt|hz|×|х)$/i.test(t)) return false;
        return true;
      });
      model = kept.join(" ").trim();
    }
    if (model && model.length >= 2) {
      data.attributes.push({ id: 9048, name: "Название модели", value: model });
      dbg.attributeSources.push("attribute-9048-from-name");
      console.log(`[zhumeng-extract] attribute 9048 (Название модели) 自动提取: "${model}"`);
    }
  }

  // ========== 9. 提取 country_of_origin (原产国) ==========
	  if (!data.country_of_origin && data.attributes.length > 0) {
	    const countryAttr = data.attributes.find(a => {
	      const n = a.name.toLowerCase();
	      return n.includes("страна") || n.includes("country") || n.includes("产地") || n.includes("国家");
	    });
	    if (countryAttr) data.country_of_origin = countryAttr.value;
	  }

  // ========== 9.5. 提取 Ozon 富内容 JSON (attribute 11254) ==========
  try {
    const richContent = await collectRichContentFromOzonPage(sku);
    if (richContent) {
      data.richContent = richContent;
      data.attributes.push({ id: 11254, name: "JSON Rich Content", value: richContent });
      dbg.richContentBytes = richContent.length;
      dbg.attributeSources.push("rich-content.11254");
    }
  } catch (e) {
    dbg.richContentError = e.message || String(e);
  }

	  // ========== 10. 调试信息 ==========
  // 截断 attributes 数组, 避免 _debug 太大
  dbg.attributesFound = data.attributes.length;
  dbg.attributesFirst3 = data.attributes.slice(0, 3);
  dbg.fullStateKeys = dbg.fullStateObject ? Object.keys(dbg.fullStateObject) : null;

	  // _debug 不返回 fullStateObject (太大), 只返回关键 keys
	  delete dbg.fullStateObject;
	  delete data._imageKeys;
	  delete data._attrKeys;

	  data._debug = dbg;
  return data;

  } catch (e) {
    console.error("[zhumeng-extract] FATAL 抛错:", e.message, e.stack);
    return {
      sku: String(sku || ""),
      name: "",
      description_category_id: 0,
      type_id: 0,
      images: [],
      attributes: [],
      _error: e.message,
      _stack: (e.stack || "").slice(0, 500),
      raw_url: location.href,
    };
  }
}





// ========== 消息监听 ==========
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log(`[SW ${VERSION}] 收到消息:`, msg.action, msg.skus ? `(${msg.skus.length} SKU)` : "");

  if (msg.action === "ping") {
    sendResponse({ ok: true, version: VERSION });
    return;
  }

  // v2.2.9.5: 让 ERP 强制 reload plugin (cache 不更新时用)
  if (msg.action === "reloadPlugin") {
    console.log(`[SW ${VERSION}] 收到 reloadPlugin 请求, 1s 后 reload service worker`);
    setTimeout(() => chrome.runtime.reload(), 1000);
    sendResponse({ ok: true, willReload: true });
    return;
  }

  if (msg.action === "diagnose") {
    (async () => {
      const diag = { version: VERSION, timestamp: new Date().toISOString() };
      try {
        const cookies = await chrome.cookies.getAll({ url: "https://seller.ozon.ru" });
        diag.sellerCookies = cookies.length;
        diag.sessionCookies = cookies.filter((c) =>
          c.name.includes("access-token") || c.name.includes("session") ||
          c.name.includes("auth") || c.name.includes("token")
        ).length;
      } catch (e) { diag.cookieError = e.message; }
      try {
        const ozonTabs = await chrome.tabs.query({ url: "https://www.ozon.ru/*" });
        diag.ozonTabs = ozonTabs.length;
      } catch (e) { diag.tabError = e.message; }
      console.log(`[SW ${VERSION}] diagnose:`, JSON.stringify(diag));
      sendResponse({ ok: true, diag });
    })();
    return true;
  }

  if (msg.action === "configureWorkerAuth") {
    (async () => {
      try {
        const result = await configureWorkerAuth(msg.token || "");
        sendResponse(result);
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e), version: VERSION });
      }
    })();
    return true;
  }

  if (msg.action === "collectSkus") {
    const skus = msg.skus || [];
    const storeIds = msg.storeIds || [];  // v2.1: ERP 传店铺 ID
    (async () => {
      const results = {};
      const errors = {};
      console.log(`[SW ${VERSION}] collectSkus 开始: ${skus.length} 个 SKU, ${storeIds.length} 个店铺`);
      for (const sku of skus) {
        try {
          results[sku] = await collectSku(sku, storeIds);
        } catch (e) {
          errors[sku] = e.message;
          console.error(`[SW ${VERSION}] ✗ 采集失败 ${sku}:`, e.message);
        }
      }
      const okCount = Object.keys(results).length;
      const failCount = Object.keys(errors).length;
      console.log(`[SW ${VERSION}] collectSkus 完成: ${okCount} 成功, ${failCount} 失败`);
      sendResponse({ ok: true, results, errors });
    })();
    return true;
  }

  if (msg.action === "portalImport") {
    (async () => {
      try {
        const result = await portalImportItems(msg.items || [], sender?.tab?.id || null);
        sendResponse({ ok: true, result });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e), version: VERSION });
      }
    })();
    return true;
  }

  if (msg.action === "checkStatus") {
    (async () => {
      // 简化: 只看 seller.ozon.ru cookie
      try {
        const cookies = await chrome.cookies.getAll({ url: "https://seller.ozon.ru" });
        const sessionCookies = cookies.filter((c) =>
          c.name.includes("access-token") || c.name.includes("session") ||
          c.name.includes("auth") || c.name.includes("token")
        );
        sendResponse({
          ok: true,
          seller_connected: sessionCookies.length > 0,
          session_valid: sessionCookies.length > 0,
          hasSellerTab: false,
          tabCount: 0,
          version: VERSION,
        });
      } catch (e) {
        sendResponse({ ok: false, error: e.message, version: VERSION });
      }
    })();
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  startSourcingQueueLoop();
});

chrome.runtime.onStartup.addListener(() => {
  startSourcingQueueLoop();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm?.name === "zhumeng-single-sourcing") {
    pollSourcingQueueOnce();
  }
});

startSourcingQueueLoop();

console.log(`[逐梦采集器 v${VERSION}] Service Worker 已加载 (${new Date().toISOString()}) - 新策略: 采集 www.ozon.ru 商品前端页 DOM`);

// v2.1.8 helper: 把 OPI attributes 合并到公开页采集的 data.attributes
//   公开页拿到 id+name+value 占位, OPI 更准的 values 用同 id 覆盖, 缺则 push
function mapOpiAttributes(opiAttrs, currentAttrs) {
  const attrs = Array.isArray(currentAttrs) ? [...currentAttrs] : [];
  let added = 0, overridden = 0;
  for (const a of (opiAttrs || [])) {
    const id = a.id;
    const name = a.name || "";
    let value = "";
    if (Array.isArray(a.values) && a.values.length) {
      value = a.values.map(v => v.value || v.text || "").filter(Boolean).join(", ");
    } else if (a.value !== undefined) {
      value = String(a.value);
    }
    if (!name && !value) continue;
    const idx = attrs.findIndex(x => x.id === id);
    const attrObj = { id, name, value };
    if (idx >= 0) {
      attrs[idx] = attrObj;
      overridden++;
    } else {
      attrs.push(attrObj);
      added++;
    }
  }
  return { attrs, added, overridden };
}
