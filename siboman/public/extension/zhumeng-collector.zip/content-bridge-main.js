/**
 * 逐梦 Ozon 采集器 - Content Bridge (MAIN world) v1.0.6
 *
 * 这个脚本在 MAIN world 跑, 主要做三件事:
 *   1. 拦截 window.postMessage: 把 __zhumeng 协议消息转成 CustomEvent (__zhumeng_request__)
 *   2. 拦截 window.addEventListener('message'): 把 handler 存到 messageHandlers
 *   3. 监听 __zhumeng_reply__ CustomEvent: dispatch 'message' 事件给所有 messageHandlers
 *
 * 配合 content-bridge-iso.js (ISOLATED world) 使用, 实现稳定的跨 world 通信.
 * ERP 端代码 (BatchUpload.js) 完全不用改.
 */
(function () {
  "use strict";
  const PROTO = "__zhumeng_proto";
  const PROTO_VAL = "zhumeng-v1";
  const VERSION = "1.0.6";

  console.log(`[逐梦采集器 v${VERSION}][MAIN] 启动`);

  // 1. 拦截 window.postMessage
  const origPostMessage = window.postMessage.bind(window);
  window.postMessage = function (msg, targetOrigin) {
    if (msg && typeof msg === "object" && msg[PROTO] === PROTO_VAL) {
      // 跨 world 通信: 用 CustomEvent (document 共享)
      document.dispatchEvent(new CustomEvent("__zhumeng_request__", { detail: msg }));
    } else {
      origPostMessage(msg, targetOrigin);
    }
  };

  // 2. 拦截 window.addEventListener('message'), 把 handler 存起来
  const messageHandlers = new Set();
  const origAddEventListener = window.addEventListener.bind(window);
  window.addEventListener = function (type, handler, ...args) {
    if (type === "message") {
      messageHandlers.add(handler);
    } else {
      return origAddEventListener(type, handler, ...args);
    }
  };

  // 3. 监听 __zhumeng_reply__ CustomEvent, dispatch 'message' 事件给所有 messageHandlers
  document.addEventListener("__zhumeng_reply__", (event) => {
    const data = event.detail;
    if (data) {
      const messageEvent = new MessageEvent("message", { data });
      messageHandlers.forEach((h) => {
        try {
          h(messageEvent);
        } catch (e) {
          console.error(`[逐梦采集器 v${VERSION}][MAIN] handler 异常:`, e);
        }
      });
    }
  });

  // 验证 init
  console.log(`[逐梦采集器 v${VERSION}][MAIN] 注入完成, 已拦截 window.postMessage + window.addEventListener, messageHandlers 数量=${messageHandlers.size}`);

  // 提供调试接口: ERP 可以 window.__zhumeng_status() 看是否就绪
  window.__zhumeng_status = () => ({
    version: VERSION,
    postMessagePatched: window.postMessage.toString().includes("__zhumeng_request__"),
    addEventListenerPatched: window.addEventListener.toString().includes("messageHandlers"),
    messageHandlersCount: messageHandlers.size,
  });
})();
